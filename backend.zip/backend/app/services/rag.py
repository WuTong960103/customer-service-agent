"""
晨星家居智能客服助手 - RAG知识库服务
"""
from typing import List, Dict, Any, Optional
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.core.config import settings
from app.core.logger import agent_logger
from app.services.embedding import vector_store_service


class RAGService:
    """
    RAG知识库服务
    负责知识检索和答案生成
    """

    def __init__(self):
        """初始化RAG服务"""
        self.llm = ChatOpenAI(
            api_key=settings.qwen_api_key,
            base_url=settings.qwen_base_url,
            model=settings.qwen_model_name,
            temperature=0.3
        )

        # 知识检索提示词模板
        self.qa_prompt = ChatPromptTemplate.from_messages([
            ("system", """你是晨星家居的智能客服助手。请根据提供的知识库内容回答用户问题。

要求：
1. 只基于知识库内容回答，不要编造信息
2. 如果知识库中没有相关信息，诚实告知用户
3. 回答要简洁明了，条理清晰
4. 语气亲切友好，体现专业素养
5. 如果问题涉及多个方面，分点回答

知识库内容:
{context}"""),
            ("human", "{question}")
        ])

        agent_logger.info("RAG服务初始化完成")

    def _get_knowledge_store(self):
        """获取最新的知识库向量库实例"""
        return vector_store_service.get_knowledge_store()

    async def retrieve_knowledge(
            self,
            query: str,
            top_k: int = 3,
            score_threshold: float = 0.3
    ) -> List[Dict[str, Any]]:
        """
        检索相关知识

        Args:
            query: 查询文本
            top_k: 返回结果数量
            score_threshold: 相似度阈值

        Returns:
            检索到的知识列表
        """
        agent_logger.info(f"开始知识检索，查询: {query}")

        # 每次获取最新的knowledge_store
        knowledge_store = self._get_knowledge_store()

        # 检查知识库文档数量
        doc_count = knowledge_store._collection.count()
        agent_logger.info(f"知识库文档数量: {doc_count}")

        results = knowledge_store.similarity_search_with_score(
            query,
            k=top_k
        )
        agent_logger.info(f"向量检索返回 {len(results)} 条原始结果")

        knowledge_list = []
        for doc, score in results:
            # Chroma 返回的是 L2 距离（欧氏距离），值越小越相似
            # 转换为相似度分数：使用 1/(1+score) 将距离映射到 (0,1] 区间
            similarity = 1 / (1 + score)
            agent_logger.debug(f"文档相似度: {similarity:.4f}, L2距离: {score:.4f}, 内容: {doc.page_content[:50]}...")
            if similarity >= score_threshold:
                knowledge_list.append({
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "similarity": similarity
                })

        agent_logger.info(f"检索到 {len(knowledge_list)} 条相关知识")
        return knowledge_list

    async def generate_answer(
            self,
            question: str,
            knowledge_list: List[Dict[str, Any]],
            conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> str:
        """
        基于检索到的知识生成答案

        Args:
            question: 用户问题
            knowledge_list: 检索到的知识列表
            conversation_history: 对话历史

        Returns:
            生成的答案
        """
        agent_logger.info(f"开始生成答案，问题: {question}")

        if not knowledge_list:
            return "抱歉，我在知识库中没有找到与您问题相关的信息。建议您联系人工客服获取更详细的帮助。"

        # 构建上下文
        context = "\n\n".join([
            f"【{k['metadata'].get('category', '知识')} - {k['metadata'].get('topic', '主题')}】\n{k['content']}"
            for k in knowledge_list
        ])

        # 如果有对话历史，添加到问题中
        if conversation_history:
            history_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else '客服'}: {msg['content']}"
                for msg in conversation_history[-4:]
            ])
            question = f"对话历史:\n{history_text}\n\n当前问题: {question}"

        chain = self.qa_prompt | self.llm | StrOutputParser()

        try:
            answer = await chain.ainvoke({
                "context": context,
                "question": question
            })
            agent_logger.info(f"答案生成完成")
            return answer
        except Exception as e:
            agent_logger.error(f"答案生成失败: {e}")
            return "抱歉，生成答案时遇到了问题。请稍后再试或联系人工客服。"

    async def query(
            self,
            question: str,
            conversation_history: Optional[List[Dict[str, str]]] = None,
            top_k: int = 3
    ) -> Dict[str, Any]:
        """
        完整的RAG查询流程

        Args:
            question: 用户问题
            conversation_history: 对话历史
            top_k: 检索结果数量

        Returns:
            包含答案和来源的字典
        """
        # 检索知识
        knowledge_list = await self.retrieve_knowledge(question, top_k=top_k)

        # 生成答案
        answer = await self.generate_answer(
            question,
            knowledge_list,
            conversation_history
        )

        return {
            "answer": answer,
            "sources": [
                {
                    "category": k["metadata"].get("category", ""),
                    "topic": k["metadata"].get("topic", ""),
                    "similarity": k["similarity"]
                }
                for k in knowledge_list
            ],
            "has_relevant_knowledge": len(knowledge_list) > 0
        }

    async def stream_query(
            self,
            question: str,
            conversation_history: Optional[List[Dict[str, str]]] = None,
            top_k: int = 3
    ):
        """
        流式RAG查询

        Args:
            question: 用户问题
            conversation_history: 对话历史
            top_k: 检索结果数量

        Yields:
            答案片段
        """
        # 检索知识
        knowledge_list = await self.retrieve_knowledge(question, top_k=top_k)

        if not knowledge_list:
            yield "抱歉，我在知识库中没有找到与您问题相关的信息。建议您联系人工客服获取更详细的帮助。"
            return

        # 构建上下文
        context = "\n\n".join([
            f"【{k['metadata'].get('category', '知识')} - {k['metadata'].get('topic', '主题')}】\n{k['content']}"
            for k in knowledge_list
        ])

        # 如果有对话历史
        if conversation_history:
            history_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else '客服'}: {msg['content']}"
                for msg in conversation_history[-4:]
            ])
            question = f"对话历史:\n{history_text}\n\n当前问题: {question}"

        chain = self.qa_prompt | self.llm

        try:
            async for chunk in chain.astream({
                "context": context,
                "question": question
            }):
                if hasattr(chunk, 'content'):
                    yield chunk.content
        except Exception as e:
            agent_logger.error(f"流式答案生成失败: {e}")
            yield "抱歉，生成答案时遇到了问题。请稍后再试或联系人工客服。"


# 全局服务实例
rag_service = RAGService()
