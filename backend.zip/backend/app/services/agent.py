"""
晨星家居智能客服助手 - Agent核心服务
实现完整的Agent运行流程：意图识别 -> 槽位填充 -> 路由 -> 执行 -> 响应

【核心架构】
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CustomerServiceAgent                                  │
│                           (智能客服Agent)                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  用户消息: "我要退货，订单号是12345"                                          │
│                           │                                                 │
│                           ▼                                                 │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  Step 1: 获取对话历史和状态                                          │    │
│  │  - conversation_manager.get_messages()                              │    │
│  │  - conversation_manager.get_conversation_state()                    │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                           │                                                 │
│                           ▼                                                 │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  Step 2: 意图识别                                                    │    │
│  │  - 检查是否在澄清状态（用户可能想切换话题）                             │    │
│  │  - 调用 intent_service.recognize_intent()                           │    │
│  │  - 返回: (意图模板, 置信度, 提取的槽位)                                │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                           │                                                 │
│                           ▼                                                 │
│              ┌────────────────────────────┐                                │
│              │   置信度 >= 0.6 ?          │                                │
│              └────────────────────────────┘                                │
│                    │              │                                        │
│                   Yes             No                                       │
│                    │              │                                        │
│                    ▼              ▼                                        │
│  ┌──────────────────────┐  ┌──────────────────────────────────────────┐   │
│  │ Step 3: 检查槽位完整性 │  │ 意图不明确处理                            │   │
│  │ 合并已有槽位+新槽位   │  │ - 尝试RAG回答                             │   │
│  │ check_slots_completion│  │ - 生成澄清问题                            │   │
│  └──────────────────────┘  └──────────────────────────────────────────┘   │
│           │                                                                │
│           ▼                                                                │
│  ┌────────────────────────────┐                                           │
│  │   槽位完整?               │                                           │
│  └────────────────────────────┘                                           │
│        │              │                                                    │
│       Yes             No                                                   │
│        │              │                                                    │
│        ▼              ▼                                                    │
│  ┌───────────┐  ┌─────────────────────────────────────────────────────┐   │
│  │ Step 4:   │  │ 槽位不完整处理                                       │   │
│  │ 路由执行   │  │ - 检查澄清次数 (最大3次)                              │   │
│  │           │  │ - 超过则转人工                                       │   │
│  └───────────┘  │ - 否则生成澄清问题                                   │   │
│        │        └─────────────────────────────────────────────────────┘   │
│        ▼                                                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                    根据 resolution_method 路由                       │  │
│  │                                                                     │  │
│  │   RAG (知识检索)      FUNCTION_CALL (工具调用)      HUMAN (转人工)   │  │
│  │        │                      │                        │            │  │
│  │        ▼                      ▼                        ▼            │  │
│  │   rag_service         agent_executor              转人工流程        │  │
│  │   .stream_query()     .ainvoke()                                    │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                           │                                                │
│                           ▼                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │  Step 5: 保存响应并清除状态                                           │  │
│  │  - conversation_manager.add_message()                                │  │
│  │  - conversation_manager.clear_conversation_state()                   │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘

【关键设计决策】
1. 置信度阈值 (CONFIDENCE_THRESHOLD = 0.6)
   - 低于此阈值视为意图不明确，需要澄清或使用RAG兜底

2. 最大澄清次数 (MAX_CLARIFICATION_COUNT = 3)
   - 避免无限循环澄清，超过后转人工

3. 流式输出 (AsyncGenerator)
   - 支持SSE推送，提升用户体验

4. 意图切换检测
   - 当用户在澄清过程中说"算了"、"不要了"等，自动切换话题
"""
import json
from typing import List, Dict, Any, Optional, AsyncGenerator
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

from app.core.config import settings
from app.core.logger import agent_logger
from app.models.schemas import (
    IntentStatus,
    ResolutionMethod,
    ConversationState,
    SlotInfo
)
from app.services.conversation import conversation_manager
from app.services.intent import intent_service
from app.services.rag import rag_service
from app.tools import ALL_TOOLS


class CustomerServiceAgent:
    """
    智能客服Agent - 系统的核心协调者

    【职责】
    1. 协调各个服务（意图识别、对话管理、RAG、工具调用）
    2. 维护对话状态机（UNKNOWN → IDENTIFIED → CLARIFYING → 完成）
    3. 根据意图的resolution_method路由到不同的处理方式
    4. 处理异常情况（超时、识别失败、工具调用失败等）

    【依赖的服务】
    - conversation_manager: 对话历史和状态管理
    - intent_service: 意图识别和槽位提取
    - rag_service: RAG知识库检索
    - agent_executor: LangGraph工具调用执行器
    """

    # ==================== 配置常量 ====================
    # 意图识别置信度阈值：低于此值视为意图不明确
    CONFIDENCE_THRESHOLD = 0.6
    # 最大澄清次数：超过后转人工，避免无限循环
    MAX_CLARIFICATION_COUNT = 3

    def __init__(self):
        """
        初始化Agent

        【初始化内容】
        1. 创建LLM客户端（通义千问）
        2. 初始化LangGraph Agent执行器（用于工具调用）

        【LLM配置说明】
        - temperature=0.7: 中等创造性，既不太死板也不太发散
        - streaming=True: 启用流式输出，提升用户体验
        """
        self.llm = ChatOpenAI(
            api_key=settings.qwen_api_key,
            base_url=settings.qwen_base_url,
            model=settings.qwen_model_name,
            temperature=0.7,  # 中等创造性
            streaming=True    # 启用流式输出
        )

        # 创建Agent执行器（用于工具调用）
        self._init_agent_executor()

        agent_logger.info("智能客服Agent初始化完成")

    def _init_agent_executor(self):
        """
        初始化Agent执行器

        【使用LangGraph的create_react_agent】
        ReAct (Reason + Act) 模式：
        1. Reason: LLM分析当前情况，决定下一步行动
        2. Act: 调用工具执行操作
        3. Observe: 观察工具返回结果
        4. 重复直到完成任务

        【工具来源】
        ALL_TOOLS: 从 app.tools 导入的所有业务工具
        包括: 订单查询、物流跟踪、退货申请等
        """
        # Agent的系统提示词，定义其角色和行为准则
        system_prompt = """你是晨星家居的智能客服助手。你需要帮助用户处理各种售后问题，包括：
- 订单查询
- 物流跟踪
- 退货退款
- 地址修改
- 发票申请
- 其他售后服务

使用工具时的注意事项：
1. 使用工具前，确保已获取必要的信息（如订单号）
2. 工具返回结果后，用自然语言总结给用户
3. 如果工具调用失败，礼貌地告知用户并提供备选方案
4. 保持回复简洁友好"""

        # 使用LangGraph创建ReAct Agent
        self.agent_executor = create_react_agent(
            self.llm,        # LLM实例
            ALL_TOOLS,       # 可用工具列表
            prompt=system_prompt  # 系统提示词
        )

    async def process_message(
            self,
            user_id: str,
            session_id: str,
            message: str
    ) -> AsyncGenerator[str, None]:
        """
        处理用户消息的核心方法（流式输出）

        这是整个智能客服系统的核心入口方法，负责协调所有子服务完成用户请求的处理。
        采用异步生成器模式，支持流式输出响应，提升用户体验。

        【方法职责】
        ┌─────────────────────────────────────────────────────────────────────┐
        │  1. 获取并维护对话上下文（历史消息 + 会话状态）                         │
        │  2. 调用意图识别服务，理解用户真实需求                                  │
        │  3. 管理多轮对话中的槽位填充流程                                       │
        │  4. 根据意图类型路由到不同的处理方式（RAG/工具调用/转人工）              │
        │  5. 处理异常情况并提供优雅降级                                         │
        └─────────────────────────────────────────────────────────────────────┘

        【处理流程概览】
        用户消息 → 获取上下文 → 意图识别 → 槽位检查 → 路由执行 → 流式响应

        【状态机转换】
        UNKNOWN ──识别成功──→ IDENTIFIED ──槽位不全──→ CLARIFYING
            │                      │                      │
            │                      │ 槽位完整              │ 补全后
            │                      ▼                      │
            └──────────────→ 执行并响应 ←─────────────────┘

        Args:
            user_id (str): 用户唯一标识符
                - 用于区分不同用户的对话
                - 与 session_id 组合形成对话的唯一键
                - 示例: "user_12345", "wx_openid_xxx"

            session_id (str): 会话唯一标识符
                - 同一用户可能有多个会话（如不同设备、不同时间段）
                - 用于隔离不同会话的上下文
                - 示例: "session_abc123", "conv_20240101_001"

            message (str): 用户输入的原始消息文本
                - 可以是任意自然语言文本
                - 示例: "我要退货，订单号是12345"
                - 示例: "查一下我的快递到哪了"

        Yields:
            str: 响应文本片段（流式输出）
                - 每次 yield 一个文本片段，前端可实时展示
                - 片段通常按句子或标点符号分割
                - 所有片段拼接后形成完整响应

        Raises:
            本方法内部捕获所有异常，不会向外抛出
            异常情况会转换为友好的错误提示返回给用户

        【使用示例】
        ```python
        async for chunk in agent.process_message("user1", "session1", "查询订单"):
            print(chunk, end="", flush=True)  # 实时打印响应
        ```

        【关键设计决策】
        1. 异步生成器: 使用 AsyncGenerator 实现流式输出，避免用户长时间等待
        2. 状态持久化: 通过 conversation_manager 持久化对话状态，支持多轮对话
        3. 意图切换检测: 在澄清过程中检测用户是否想切换话题，提升体验
        4. 优雅降级: 意图不明确时尝试 RAG 兜底，多次失败后转人工

        【性能考虑】
        - 对话历史限制为最近 N 条（由 settings.max_history_length 控制）
        - 使用流式输出减少首字节响应时间
        - 异步调用避免阻塞

        【安全考虑】
        - user_id 和 session_id 用于数据隔离，防止跨用户数据泄露
        - 所有用户输入都会经过意图识别，不会直接执行
        """
        # ==================== 日志记录：标记处理开始 ====================
        # 使用分隔线便于在日志中快速定位每次请求的开始位置
        agent_logger.info(f"=" * 50)
        agent_logger.info(f"[Agent] 开始处理消息 - 用户: {user_id}, 会话: {session_id}")
        agent_logger.info(f"[Agent] 用户消息: {message}")

        # ==================== Step 1: 获取对话历史和状态 ====================
        # 【目的】恢复对话上下文，实现多轮对话的连续性
        #
        # 获取历史消息列表，用于：
        # 1. 提供给意图识别服务，帮助理解上下文语境
        # 2. 提供给 LLM 生成更连贯的回复
        # 3. 实现指代消解（如"它"、"这个订单"等指代词的理解）
        #
        # limit 参数限制历史长度，避免：
        # - Token 消耗过多
        # - 上下文过长导致 LLM 性能下降
        # - 内存占用过大
        history = conversation_manager.get_messages(user_id, session_id, limit=settings.max_history_length)

        # 获取当前会话状态，包含：
        # - current_intent: 当前识别到的意图名称
        # - intent_status: 意图状态（UNKNOWN/IDENTIFIED/CLARIFYING）
        # - slots: 已收集的槽位信息
        # - clarification_count: 已澄清次数（用于防止无限循环）
        state = conversation_manager.get_conversation_state(user_id, session_id)

        # 如果是新会话或状态丢失，创建初始状态
        # 初始状态：意图未知，槽位为空，澄清次数为0
        if not state:
            state = ConversationState(user_id=user_id, session_id=session_id)

        # 将 LangChain 消息对象转换为简单字典格式
        # 这种格式更通用，便于传递给各个服务
        # 格式: [{"role": "user"|"assistant", "content": "消息内容"}, ...]
        conversation_history = [
            {"role": "user" if isinstance(msg, HumanMessage) else "assistant", "content": msg.content}
            for msg in history
        ]

        # 记录当前上下文信息，便于调试和问题排查
        agent_logger.info(f"[Agent] 对话历史长度: {len(conversation_history)}")
        agent_logger.info(f"[Agent] 当前状态 - 意图: {state.current_intent}, 状态: {state.intent_status}")

        # ==================== Step 2: 保存用户消息 ====================
        # 【重要】先保存用户消息，确保即使后续处理失败，用户输入也不会丢失
        # 这对于：
        # 1. 对话历史的完整性
        # 2. 问题排查和用户行为分析
        # 3. 断点续传（如果处理中断，下次可以继续）
        conversation_manager.add_message(user_id, session_id, "user", message)

        # ==================== Step 3: 意图识别 ====================
        # 【核心步骤】理解用户想要做什么
        #
        # 意图识别是整个对话系统的关键，决定了后续的处理路径
        # 识别结果包含三个要素：
        # 1. intent: 意图模板对象，包含意图名称、所需槽位、解决方式等
        # 2. confidence: 置信度 (0-1)，表示识别的确定程度
        # 3. extracted_slots: 从用户消息中提取的槽位值
        agent_logger.info("[Agent] 步骤1: 意图识别")

        # -------------------- 意图切换检测 --------------------
        # 【场景】用户在多轮对话中可能改变主意
        #
        # 例如：
        # - 用户: "我要退货" → Agent: "请提供订单号"
        # - 用户: "算了，我想查物流" ← 用户改变了意图！
        #
        # 如果不检测意图切换，系统会错误地认为"算了，我想查物流"是在补充订单号
        # 导致糟糕的用户体验
        if state.intent_status == IntentStatus.CLARIFYING and state.current_intent:
            # 当前正在澄清槽位（等待用户补充信息）
            # 需要先判断用户是想继续补充信息，还是想切换到新话题

            # 调用意图切换检测服务
            # 该服务会分析用户消息，判断是否包含切换意图的信号词
            # 如："算了"、"不要了"、"换一个问题"、"我想问别的" 等
            wants_switch, switch_reason = await intent_service.check_intent_switch(
                message, state.current_intent, conversation_history
            )

            if wants_switch:
                # ===== 用户想切换意图 =====
                # 清除当前对话状态，从头开始识别新意图
                # 这样可以避免旧意图的槽位信息干扰新意图的处理
                agent_logger.info(f"[Agent] 用户想切换意图，原因: {switch_reason}，清除当前状态")
                conversation_manager.clear_conversation_state(user_id, session_id)

                # 重置为初始状态
                state = ConversationState(user_id=user_id, session_id=session_id)

                # 对新消息进行完整的意图识别
                intent, confidence, extracted_slots = await intent_service.recognize_intent(
                    message, conversation_history, state
                )
            else:
                # ===== 用户继续补充信息 =====
                # 保持原有意图不变，只提取新的槽位值
                agent_logger.info(f"[Agent] 当前正在补充槽位，保持原有意图: {state.current_intent}")

                # 根据意图名称获取完整的意图模板
                # 意图模板包含：所需槽位定义、解决方式、响应模板等
                intent = await intent_service.get_intent_by_name(state.current_intent)

                if intent:
                    # 只提取槽位值，不重新识别意图
                    # 这样可以：
                    # 1. 避免意图识别的不稳定性
                    # 2. 提高槽位提取的准确性（因为已知意图上下文）
                    # 3. 减少 LLM 调用次数，提升性能
                    extracted_slots = await intent_service.extract_slots_only(
                        message, intent, conversation_history
                    )
                    # 设置高置信度，因为意图已经在之前确认过
                    confidence = 0.95
                    agent_logger.info(f"[Agent] 使用原意图: {intent.intent_name}, 提取槽位: {extracted_slots}")
                else:
                    # 异常情况：原意图模板未找到（可能被删除或配置变更）
                    # 降级处理：重新进行完整的意图识别
                    agent_logger.warning(f"[Agent] 原意图 {state.current_intent} 未找到，重新识别")
                    intent, confidence, extracted_slots = await intent_service.recognize_intent(
                        message, conversation_history, state
                    )
        else:
            # -------------------- 常规意图识别 --------------------
            # 非澄清状态，进行完整的意图识别流程
            # 这是大多数情况下的处理路径（新对话或意图未知状态）
            intent, confidence, extracted_slots = await intent_service.recognize_intent(
                message, conversation_history, state
            )

        # 记录意图识别结果，便于调试和分析
        agent_logger.info(f"[Agent] 意图识别结果 - 意图: {intent.intent_name if intent else None}, 置信度: {confidence}")
        agent_logger.info(f"[Agent] 提取的槽位: {extracted_slots}")

        # ==================== Step 4: 根据置信度分支处理 ====================
        # 【决策点】置信度阈值判断
        #
        # 置信度 >= 0.6: 意图明确，进入槽位检查和执行流程
        # 置信度 < 0.6:  意图不明确，尝试 RAG 兜底或生成澄清问题
        #
        # 阈值 0.6 的选择依据：
        # - 太高（如 0.8）：会导致很多正常请求被误判为不明确
        # - 太低（如 0.4）：会导致错误的意图被执行
        # - 0.6 是经验值，可根据实际业务调整
        if intent and confidence >= self.CONFIDENCE_THRESHOLD:
            # ==================== 分支A: 意图明确 ====================

            # -------------------- 槽位合并 --------------------
            # 【目的】将多轮对话中收集的槽位信息合并
            #
            # 场景示例：
            # - 第一轮: "我要退货" → 提取到意图，但没有订单号
            # - 第二轮: "订单号是12345" → 提取到订单号
            # 需要将两轮的信息合并，才能完成退货操作
            #
            # 合并策略：新值覆盖旧值（用户最新提供的信息优先）
            merged_slots = dict(state.slots)  # 复制已有槽位，避免修改原对象

            for slot_name, slot_value in extracted_slots.items():
                if slot_value:  # 只合并非空值
                    # 将提取的槽位值包装为 SlotInfo 对象
                    # SlotInfo 包含：name, description, value, extracted 等字段
                    merged_slots[slot_name] = SlotInfo(
                        name=slot_name,
                        description="",  # 描述信息在意图模板中定义
                        value=str(slot_value),  # 统一转为字符串存储
                        extracted=True  # 标记为已提取
                    )

            # -------------------- 更新会话状态 --------------------
            # 将识别结果持久化到会话状态中
            # 这样即使用户中断对话，下次回来也能继续
            state = conversation_manager.update_conversation_state(
                user_id, session_id,
                intent=intent.intent_name,  # 更新当前意图
                intent_status=IntentStatus.IDENTIFIED,  # 状态变为"已识别"
                slots=merged_slots  # 更新槽位信息
            )

            # ==================== Step 5: 检查槽位完整性 ====================
            # 【目的】判断是否收集到了执行操作所需的全部信息
            #
            # 不同意图需要不同的槽位：
            # - 查询订单: 需要 order_id
            # - 退货申请: 需要 order_id, reason
            # - 修改地址: 需要 order_id, new_address
            #
            # 只有槽位完整，才能执行相应的业务操作
            agent_logger.info("[Agent] 步骤2: 检查槽位完整性")

            # 提取已填充的槽位值（只保留有值的槽位）
            filled_slots = {k: v.value for k, v in merged_slots.items() if v.value}

            # 调用意图服务检查槽位完整性
            # 返回：(是否完整, 缺失的槽位列表)
            is_complete, missing_slots = await intent_service.check_slots_completion(intent, filled_slots)

            if not is_complete:
                # ==================== 槽位不完整：需要向用户询问更多信息 ====================
                # 【场景】用户说"我要退货"，但没有提供订单号
                # 【处理】生成澄清问题，引导用户提供缺失信息
                agent_logger.info(f"[Agent] 槽位不完整，缺失: {[s.name for s in missing_slots]}")

                # -------------------- 澄清次数检查 --------------------
                # 【防护机制】避免无限循环澄清
                #
                # 场景：用户可能一直提供无效信息，或者系统无法正确提取
                # 如果不限制澄清次数，会导致：
                # 1. 用户体验极差（被反复追问）
                # 2. 系统资源浪费
                # 3. 可能陷入死循环
                #
                # 解决方案：设置最大澄清次数（默认3次），超过后转人工
                if state.clarification_count >= self.MAX_CLARIFICATION_COUNT:
                    # 超过最大澄清次数，优雅降级到人工服务
                    agent_logger.info("[Agent] 超过最大澄清次数，转人工处理")

                    # 生成友好的转人工提示
                    response = "抱歉，我可能没有完全理解您的需求。让我为您转接人工客服，他们会更好地帮助您。"

                    # 流式输出响应
                    async for chunk in self._stream_response(response):
                        yield chunk

                    # 保存助手响应到对话历史
                    conversation_manager.add_message(user_id, session_id, "assistant", response)

                    # 提前返回，结束本次处理
                    return

                # -------------------- 生成澄清问题 --------------------
                # 更新状态为"澄清中"，并增加澄清计数
                state = conversation_manager.update_conversation_state(
                    user_id, session_id,
                    intent_status=IntentStatus.CLARIFYING,  # 状态变为"澄清中"
                    clarification_count=state.clarification_count + 1  # 澄清次数+1
                )

                # 调用意图服务生成自然的澄清问题
                # 澄清问题会根据缺失的槽位动态生成
                # 例如：缺少订单号 → "请问您的订单号是多少？"
                # 例如：缺少退货原因 → "请问您退货的原因是什么？"
                clarification = await intent_service.generate_clarification(
                    message, intent, missing_slots, conversation_history
                )

                agent_logger.info(f"[Agent] 生成澄清问题: {clarification}")

                # 流式输出澄清问题
                async for chunk in self._stream_response(clarification):
                    yield chunk

                # 保存澄清问题到对话历史
                conversation_manager.add_message(user_id, session_id, "assistant", clarification)

                # 返回，等待用户下一轮输入
                return

            # ==================== Step 6: 槽位完整，执行相应操作 ====================
            # 【核心路由】根据意图的 resolution_method 分发到不同的处理器
            #
            # resolution_method 定义了如何解决用户的问题：
            # - RAG: 从知识库检索答案（适用于FAQ、政策咨询等）
            # - FUNCTION_CALL: 调用业务工具（适用于订单查询、退货申请等）
            # - HUMAN: 转接人工客服（适用于复杂问题、投诉等）
            agent_logger.info(f"[Agent] 步骤3: 路由到解决方式 - {intent.resolution_method}")

            # 用于收集完整响应（流式输出时需要累积）
            response = ""

            # ==================== 路由分支1: RAG 知识检索 ====================
            if intent.resolution_method == ResolutionMethod.RAG:
                # 【适用场景】
                # - 产品咨询："这款沙发的材质是什么？"
                # - 政策查询："退货政策是怎样的？"
                # - FAQ："如何申请发票？"
                #
                # 【处理方式】
                # 从向量知识库中检索相关文档，结合 LLM 生成回答
                agent_logger.info("[Agent] 使用RAG知识库回答")

                try:
                    # 调用 RAG 服务进行流式查询
                    # stream_query 会：
                    # 1. 将用户问题向量化
                    # 2. 在向量库中检索相似文档
                    # 3. 将检索结果和问题一起发给 LLM
                    # 4. 流式返回 LLM 生成的回答
                    async for chunk in rag_service.stream_query(message, conversation_history):
                        response += chunk  # 累积完整响应
                        yield chunk  # 流式输出给前端

                    # 检查是否获取到有效回答
                    # 可能的失败情况：知识库中没有相关内容
                    if not response.strip():
                        # 生成兜底响应
                        response = f"抱歉，暂时未能找到关于「{intent.intent_name}」的相关信息。您可以尝试换个方式描述问题，或联系人工客服获取帮助。"
                        async for chunk in self._stream_response(response):
                            yield chunk

                except Exception as e:
                    # RAG 查询异常处理
                    # 可能的异常：向量库连接失败、LLM 调用超时等
                    agent_logger.error(f"[Agent] RAG查询失败: {e}")

                    # 生成友好的错误提示，并提供备选方案
                    response = f"""抱歉，在查询「{intent.intent_name}」相关信息时遇到了问题。

您可以：
1. 稍后重试
2. 联系人工客服获取帮助

如需转接人工客服，请回复"转人工"。"""
                    async for chunk in self._stream_response(response):
                        yield chunk

            # ==================== 路由分支2: 工具调用（Function Call）====================
            elif intent.resolution_method == ResolutionMethod.FUNCTION_CALL:
                # 【适用场景】
                # - 订单查询："帮我查一下订单12345的状态"
                # - 物流跟踪："我的快递到哪了？"
                # - 退货申请："我要退货"
                # - 地址修改："帮我改一下收货地址"
                #
                # 【处理方式】
                # 使用 LangGraph ReAct Agent 调用业务工具
                # Agent 会自动选择合适的工具并执行
                agent_logger.info("[Agent] 调用业务工具")

                # 调用工具执行方法
                # 传入：用户消息、对话历史、已填充的槽位、意图名称
                # 返回：{"success": bool, "response": str, "error": str}
                tool_result = await self._execute_with_tools(message, conversation_history, filled_slots, intent.intent_name)

                if tool_result["success"]:
                    # ===== 工具调用成功 =====
                    response = tool_result["response"]
                    agent_logger.info(f"[Agent] 工具调用成功: {response[:100]}...")
                else:
                    # ===== 工具调用失败 =====
                    # 可能的失败原因：
                    # - 订单不存在
                    # - 网络超时
                    # - 权限不足
                    # - 业务规则限制（如已发货不能修改地址）
                    error_msg = tool_result.get("error", "未知错误")
                    agent_logger.error(f"[Agent] 工具调用失败: {error_msg}")

                    # 生成包含错误原因和备选方案的响应
                    response = f"""抱歉，在处理您的「{intent.intent_name}」请求时遇到了问题。

**失败原因**: {error_msg}

您可以：
1. 稍后重试
2. 联系人工客服获取帮助

如需转接人工客服，请回复"转人工"。"""

                # 流式输出工具调用结果
                async for chunk in self._stream_response(response):
                    yield chunk

            # ==================== 路由分支3: 转人工 ====================
            elif intent.resolution_method == ResolutionMethod.HUMAN:
                # 【适用场景】
                # - 用户主动要求："转人工"
                # - 复杂投诉："我要投诉你们的服务"
                # - 敏感问题：涉及法律、安全等
                #
                # 【处理方式】
                # 生成转人工提示，触发转人工流程
                # 实际的转人工逻辑可能需要对接工单系统或客服系统
                agent_logger.info("[Agent] 转接人工客服")

                # 生成转人工响应
                # 【系统提示】标记用于前端识别，触发转人工 UI
                response = "好的，我现在为您转接人工客服。请稍候，人工客服将很快与您联系。\n\n【系统提示：已触发转人工流程】"

                async for chunk in self._stream_response(response):
                    yield chunk

            # -------------------- 保存响应并清理状态 --------------------
            # 保存助手响应到对话历史
            conversation_manager.add_message(user_id, session_id, "assistant", response)

            # 清除对话状态（意图已完成处理）
            # 这样下一轮对话会从全新状态开始
            # 注意：对话历史不会清除，只清除意图相关的状态
            conversation_manager.clear_conversation_state(user_id, session_id)

        else:
            # ==================== 分支B: 意图不明确 ====================
            # 【触发条件】置信度 < 0.6 或未识别到任何意图
            #
            # 【可能的原因】
            # 1. 用户表达模糊："我有个问题"
            # 2. 超出业务范围："今天天气怎么样？"
            # 3. 意图识别模型能力不足
            # 4. 用户输入包含错别字或非标准表达
            #
            # 【处理策略】
            # 1. 先尝试用 RAG 知识库回答（可能是知识咨询类问题）
            # 2. 如果 RAG 也无法回答，生成澄清问题
            # 3. 多次澄清失败后，转人工
            agent_logger.info(f"[Agent] 意图不明确，置信度: {confidence}")

            # -------------------- 澄清次数检查 --------------------
            # 同样需要防止无限循环
            if state.clarification_count >= self.MAX_CLARIFICATION_COUNT:
                # 多次尝试后仍无法理解用户意图，转人工处理
                agent_logger.info("[Agent] 超过最大澄清次数，转人工处理")

                # 生成更详细的转人工提示
                response = "非常抱歉，我暂时无法理解您的问题。让我为您转接人工客服，他们会更好地帮助您解决问题。\n\n【系统提示：已触发转人工流程】"

                async for chunk in self._stream_response(response):
                    yield chunk

                # 保存响应并清理状态
                conversation_manager.add_message(user_id, session_id, "assistant", response)
                conversation_manager.clear_conversation_state(user_id, session_id)

                # 结束处理
                return

            # -------------------- 更新澄清计数 --------------------
            # 即使意图不明确，也要记录澄清次数
            # 这样可以追踪用户在"意图不明确"状态下的交互次数
            conversation_manager.update_conversation_state(
                user_id, session_id,
                intent_status=IntentStatus.UNKNOWN,  # 保持未知状态
                clarification_count=state.clarification_count + 1  # 澄清次数+1
            )

            # -------------------- RAG 兜底尝试 --------------------
            # 【策略】意图不明确时，先尝试用知识库回答
            #
            # 原因：用户可能在问一个知识性问题，而不是要执行某个操作
            # 例如："你们的退货政策是什么？" 可能被识别为意图不明确
            # 但实际上可以通过 RAG 从知识库中找到答案
            agent_logger.info("[Agent] 尝试使用RAG知识库回答")

            # 调用 RAG 服务查询（非流式，因为需要先判断是否有相关知识）
            rag_result = await rag_service.query(message, conversation_history)

            if rag_result["has_relevant_knowledge"]:
                # ===== RAG 找到相关知识 =====
                # 直接使用 RAG 的回答
                response = rag_result["answer"]

                async for chunk in self._stream_response(response):
                    yield chunk
            else:
                # ===== RAG 也无法回答 =====
                # 生成澄清问题，引导用户更清晰地表达需求
                #
                # 澄清问题示例：
                # - "请问您是想查询订单、退货，还是有其他问题呢？"
                # - "抱歉，我没有完全理解您的意思，能否请您详细描述一下？"
                clarification = await intent_service.generate_clarification(
                    message,
                    None,  # 意图为空，生成通用澄清问题
                    [],    # 无缺失槽位
                    conversation_history
                )
                response = clarification

                async for chunk in self._stream_response(response):
                    yield chunk

            # 保存助手响应到对话历史
            conversation_manager.add_message(user_id, session_id, "assistant", response)

        # ==================== 处理完成 ====================
        # 记录处理完成日志，便于追踪和性能分析
        agent_logger.info(f"[Agent] 处理完成")
        agent_logger.info(f"=" * 50)

    async def _execute_with_tools(
            self,
            message: str,
            conversation_history: List[Dict[str, str]],
            slots: Dict[str, Any],
            intent_name: str = ""
    ) -> Dict[str, Any]:
        """
        使用工具执行操作

        Args:
            message: 用户消息
            conversation_history: 对话历史
            slots: 槽位信息
            intent_name: 意图名称

        Returns:
            执行结果字典 {"success": bool, "response": str, "error": str}
        """
        agent_logger.info(f"[Agent] 开始执行工具调用，意图: {intent_name}, 槽位: {slots}")

        # 构建上下文信息
        context = f"用户意图: {intent_name}\n已提取的信息: {json.dumps(slots, ensure_ascii=False)}"

        # 构建聊天历史
        chat_history = []
        for msg in conversation_history[-6:]:
            if msg["role"] == "user":
                chat_history.append(HumanMessage(content=msg["content"]))
            else:
                chat_history.append(AIMessage(content=msg["content"]))

        # 添加当前消息（带上下文）
        current_message = f"{context}\n\n用户问题: {message}"
        chat_history.append(HumanMessage(content=current_message))

        try:
            result = await self.agent_executor.ainvoke({
                "messages": chat_history
            })

            # 从结果中提取最后一条AI消息
            messages = result.get("messages", [])
            for msg in reversed(messages):
                if isinstance(msg, AIMessage) and msg.content:
                    agent_logger.info(f"[Agent] 工具执行成功，响应: {msg.content[:100]}...")
                    return {
                        "success": True,
                        "response": msg.content,
                        "error": None
                    }

            # 没有找到有效响应
            agent_logger.warning("[Agent] 工具执行完成但未获取到有效响应")
            return {
                "success": True,
                "response": f"您的「{intent_name}」请求已处理完成。如有其他问题，请继续告诉我。",
                "error": None
            }

        except Exception as e:
            error_message = str(e)
            agent_logger.error(f"[Agent] 工具执行异常: {error_message}")

            # 根据错误类型返回更友好的提示
            if "timeout" in error_message.lower():
                friendly_error = "服务响应超时，请稍后重试"
            elif "connection" in error_message.lower():
                friendly_error = "网络连接异常，请检查网络后重试"
            elif "not found" in error_message.lower() or "404" in error_message:
                friendly_error = "未找到相关数据，请确认信息是否正确"
            elif "permission" in error_message.lower() or "403" in error_message:
                friendly_error = "权限不足，无法执行此操作"
            else:
                friendly_error = "系统处理异常，请稍后重试"

            return {
                "success": False,
                "response": None,
                "error": friendly_error
            }

    async def _stream_response(self, text: str) -> AsyncGenerator[str, None]:
        """
        模拟流式输出

        Args:
            text: 完整文本

        Yields:
            文本片段
        """
        # 按句子分割
        import re
        sentences = re.split(r'([。！？\n])', text)
        buffer = ""

        for i, part in enumerate(sentences):
            buffer += part
            if part in ['。', '！', '？', '\n'] or i == len(sentences) - 1:
                if buffer.strip():
                    yield buffer
                    buffer = ""


# 全局Agent实例
customer_service_agent = CustomerServiceAgent()
