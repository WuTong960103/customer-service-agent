"""
晨星家居智能客服助手 - Redis对话历史管理服务
使用LangChain的Redis集成进行对话历史管理

【核心职责】
1. 会话管理：创建、查询、删除用户会话
2. 消息管理：存储和检索对话历史消息
3. 状态管理：维护每个会话的对话状态（意图、槽位、澄清次数等）
4. 数据持久化：使用Redis存储所有对话数据，支持TTL自动过期

【整体架构图】
┌─────────────────────────────────────────────────────────────────────┐
│                        ConversationManager                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────┐ │
│  │   会话管理       │  │   消息管理       │  │   状态管理          │ │
│  │  create_session │  │  add_message    │  │  get/update_state  │ │
│  │  get_sessions   │  │  get_messages   │  │  clear_state       │ │
│  │  delete_session │  │  get_history    │  │                    │ │
│  └────────┬────────┘  └────────┬────────┘  └─────────┬───────────┘ │
│           │                    │                      │             │
│           └────────────────────┼──────────────────────┘             │
│                                │                                    │
│                                ▼                                    │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                         Redis                                 │  │
│  │  ┌──────────────────┐ ┌──────────────────┐ ┌───────────────┐ │  │
│  │  │ chat:session:*   │ │ chat:state:*     │ │chat:user_*    │ │  │
│  │  │ (消息历史-List)  │ │ (状态-String)    │ │(会话列表-Hash)│ │  │
│  │  └──────────────────┘ └──────────────────┘ └───────────────┘ │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘

【数据结构详解】
Redis键设计：
┌────────────────────────────────────────────────────────────────────┐
│ Key Pattern                          │ Value Type │ 用途            │
├────────────────────────────────────────────────────────────────────┤
│ chat:session:{user_id}:{session_id}  │ List       │ LangChain消息   │
│ chat:state:{user_id}:{session_id}    │ String     │ JSON状态对象    │
│ chat:user_sessions:{user_id}         │ Hash       │ 用户的会话列表  │
└────────────────────────────────────────────────────────────────────┘

【与其他服务的关系】
┌─────────────┐     ┌─────────────────────┐     ┌─────────────────┐
│   Agent     │────▶│ ConversationManager │────▶│     Redis       │
│  (agent.py) │     │                     │     │                 │
└─────────────┘     └─────────────────────┘     └─────────────────┘
     │                       │
     │ 1.获取历史消息         │ 保存/读取
     │ 2.保存新消息           │
     │ 3.更新对话状态         │
     ▼                       ▼
┌─────────────┐     ┌─────────────────────┐
│   意图识别   │     │   槽位状态          │
│   上下文     │     │   ConversationState │
└─────────────┘     └─────────────────────┘
"""
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import uuid4

import redis
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_community.chat_message_histories import RedisChatMessageHistory

from app.core.config import settings
from app.core.logger import agent_logger
from app.models.schemas import ConversationState, IntentStatus, SlotInfo, SessionInfo


class ConversationManager:
    """
    对话管理器
    负责管理用户会话、对话历史和对话状态
    """

    def __init__(self):
        """
        初始化对话管理器

        【初始化流程】
        1. 构建Redis连接URL（用于LangChain的RedisChatMessageHistory）
        2. 创建Redis客户端（用于直接操作Redis存储状态和会话列表）
        3. 设置decode_responses=True，让Redis自动解码为字符串
        """
        # 构建Redis连接URL（格式：redis://host:port/db）
        self.redis_url = f"redis://{settings.redis_host}:{settings.redis_port}/{settings.redis_db}"

        # 创建原生Redis客户端，用于状态和会话列表管理
        self.redis_client = redis.Redis(
            host=settings.redis_host,
            port=settings.redis_port,
            db=settings.redis_db,
            decode_responses=True  # 自动将字节解码为字符串
        )
        agent_logger.info(f"对话管理器初始化完成，Redis URL: {self.redis_url}")

    def _get_session_key(self, user_id: str, session_id: str) -> str:
        """
        获取会话消息历史的Redis键名

        格式：chat:session:{user_id}:{session_id}
        用途：存储LangChain的对话消息历史（HumanMessage、AIMessage等）
        """
        return f"chat:session:{user_id}:{session_id}"

    def _get_state_key(self, user_id: str, session_id: str) -> str:
        """
        获取对话状态的Redis键名

        格式：chat:state:{user_id}:{session_id}
        用途：存储ConversationState对象（意图、槽位、澄清次数等）
        """
        return f"chat:state:{user_id}:{session_id}"

    def _get_user_sessions_key(self, user_id: str) -> str:
        """
        获取用户会话列表的Redis键名

        格式：chat:user_sessions:{user_id}
        用途：存储该用户的所有会话信息（Hash结构，key=session_id, value=session_info_json）
        """
        return f"chat:user_sessions:{user_id}"

    def create_session(self, user_id: str) -> str:
        """
        创建新会话

        【创建流程】
        1. 生成唯一的会话ID（UUID）
        2. 初始化会话状态对象（ConversationState）
        3. 将状态保存到Redis（带TTL过期时间）
        4. 将会话信息添加到用户会话列表（Hash结构）

        Args:
            user_id: 用户ID

        Returns:
            新会话ID
        """
        # 生成唯一会话ID
        session_id = str(uuid4())
        now = datetime.now()

        # 初始化会话状态（此时意图、槽位都为空）
        state = ConversationState(
            user_id=user_id,
            session_id=session_id,
            created_at=now,
            updated_at=now
        )

        # 保存状态到Redis，设置过期时间（TTL）
        state_key = self._get_state_key(user_id, session_id)
        self.redis_client.setex(
            state_key,
            settings.session_ttl,  # 会话过期时间（秒）
            state.model_dump_json()  # 将Pydantic对象序列化为JSON
        )

        # 添加到用户会话列表（Hash结构，方便查询用户的所有会话）
        user_sessions_key = self._get_user_sessions_key(user_id)
        session_info = {
            "session_id": session_id,
            "created_at": now.isoformat(),
            "updated_at": now.isoformat()
        }
        # 使用HSET将session_id作为field，session_info作为value
        self.redis_client.hset(user_sessions_key, session_id, json.dumps(session_info))
        # 设置Hash的过期时间
        self.redis_client.expire(user_sessions_key, settings.session_ttl)

        agent_logger.info(f"创建新会话 - 用户: {user_id}, 会话: {session_id}")
        return session_id

    def get_chat_history(self, user_id: str, session_id: str) -> BaseChatMessageHistory:
        """
        获取LangChain对话历史对象

        【功能说明】
        使用LangChain提供的RedisChatMessageHistory来管理消息历史。
        这个对象封装了Redis操作，自动处理消息的序列化/反序列化。

        【优势】
        - 自动管理消息的存储和检索
        - 支持多种消息类型（HumanMessage、AIMessage、SystemMessage）
        - 自动设置TTL，防止数据积压

        Args:
            user_id: 用户ID
            session_id: 会话ID

        Returns:
            LangChain对话历史对象（可直接add_message、获取messages等）
        """
        session_key = self._get_session_key(user_id, session_id)
        # 创建LangChain的Redis消息历史对象
        history = RedisChatMessageHistory(
            session_id=session_key,  # 使用我们定义的键名
            url=self.redis_url,      # Redis连接URL
            ttl=settings.session_ttl # 消息过期时间
        )
        return history

    def add_message(
            self,
            user_id: str,
            session_id: str,
            role: str,
            content: str,
            metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        添加消息到对话历史

        【处理流程】
        1. 获取LangChain的对话历史对象
        2. 根据角色创建对应的消息对象（HumanMessage/AIMessage/SystemMessage）
        3. 添加消息到Redis
        4. 更新会话的最后活跃时间

        Args:
            user_id: 用户ID
            session_id: 会话ID
            role: 消息角色 (user/assistant/system)
            content: 消息内容
            metadata: 元数据（可选，存储额外信息如意图名称、槽位等）
        """
        # 获取该会话的消息历史对象
        history = self.get_chat_history(user_id, session_id)

        # 根据角色创建不同类型的消息对象
        if role == "user":
            message = HumanMessage(content=content, additional_kwargs=metadata or {})
        elif role == "assistant":
            message = AIMessage(content=content, additional_kwargs=metadata or {})
        else:
            message = SystemMessage(content=content, additional_kwargs=metadata or {})

        # 添加消息到Redis（LangChain自动处理序列化）
        history.add_message(message)

        # 更新会话的最后活跃时间（用于排序和显示）
        self._update_session_time(user_id, session_id)

        agent_logger.debug(f"添加消息 - 用户: {user_id}, 会话: {session_id}, 角色: {role}")

    def get_messages(self, user_id: str, session_id: str, limit: Optional[int] = None) -> List[BaseMessage]:
        """
        获取对话历史消息

        【功能说明】
        从Redis中检索指定会话的所有消息，可选择性限制返回数量。
        返回的是LangChain的消息对象列表（HumanMessage、AIMessage等）。

        【使用场景】
        - Agent处理新消息前，获取上下文历史
        - 前端展示聊天记录
        - 意图识别时需要历史对话辅助判断

        Args:
            user_id: 用户ID
            session_id: 会话ID
            limit: 限制返回的消息数量（如果指定，返回最近的N条消息）

        Returns:
            消息列表（按时间顺序）
        """
        # 获取该会话的消息历史对象
        history = self.get_chat_history(user_id, session_id)
        messages = history.messages  # 获取所有消息

        # 如果指定了limit，只返回最近的N条消息
        if limit and len(messages) > limit:
            messages = messages[-limit:]  # 取最后N条（最新的）

        return messages

    def get_conversation_state(self, user_id: str, session_id: str) -> Optional[ConversationState]:
        """
        获取对话状态

        【状态内容】
        ConversationState包含：
        - current_intent: 当前识别的用户意图
        - intent_status: 意图状态（UNKNOWN/IDENTIFIED/CLARIFYING）
        - slots: 已填充的槽位信息（字典）
        - clarification_count: 澄清次数（防止无限循环澄清）
        - created_at/updated_at: 时间戳

        Args:
            user_id: 用户ID
            session_id: 会话ID

        Returns:
            对话状态对象，如果不存在返回None
        """
        state_key = self._get_state_key(user_id, session_id)
        state_data = self.redis_client.get(state_key)  # 从Redis获取JSON字符串

        if state_data:
            # 使用Pydantic的model_validate_json反序列化为对象
            return ConversationState.model_validate_json(state_data)
        return None

    def update_conversation_state(
            self,
            user_id: str,
            session_id: str,
            intent: Optional[str] = None,
            intent_status: Optional[IntentStatus] = None,
            slots: Optional[Dict[str, SlotInfo]] = None,
            clarification_count: Optional[int] = None
    ) -> ConversationState:
        """
        更新对话状态

        【更新策略】
        1. 先从Redis获取当前状态（如果不存在则创建新状态）
        2. 只更新传入的非None参数（部分更新）
        3. 更新updated_at时间戳
        4. 保存回Redis（带TTL）

        【使用场景】
        - 识别到新意图后，更新intent和intent_status
        - 提取到新槽位后，合并到slots字典
        - 每次澄清后，增加clarification_count

        Args:
            user_id: 用户ID
            session_id: 会话ID
            intent: 当前意图（可选）
            intent_status: 意图状态（可选）
            slots: 槽位信息（可选，完整替换）
            clarification_count: 澄清次数（可选）

        Returns:
            更新后的对话状态
        """
        # 获取当前状态
        state = self.get_conversation_state(user_id, session_id)

        # 如果状态不存在，创建新状态
        if not state:
            state = ConversationState(
                user_id=user_id,
                session_id=session_id
            )

        # 只更新传入的参数（部分更新）
        if intent is not None:
            state.current_intent = intent
        if intent_status is not None:
            state.intent_status = intent_status
        if slots is not None:
            state.slots = slots  # 完整替换槽位字典
        if clarification_count is not None:
            state.clarification_count = clarification_count

        # 更新时间戳
        state.updated_at = datetime.now()

        # 保存到Redis（使用setex设置过期时间）
        state_key = self._get_state_key(user_id, session_id)
        self.redis_client.setex(
            state_key,
            settings.session_ttl,
            state.model_dump_json()  # 序列化为JSON
        )

        agent_logger.debug(f"更新对话状态 - 用户: {user_id}, 会话: {session_id}, 意图: {intent}")
        return state

    def clear_conversation_state(self, user_id: str, session_id: str) -> None:
        """
        清除对话状态（重置意图和槽位）

        【使用场景】
        - 用户意图处理完成后，清除状态以准备下一个意图
        - 用户主动切换话题时
        - 超过最大澄清次数转人工后

        【清除内容】
        - current_intent: 重置为None
        - intent_status: 重置为UNKNOWN
        - slots: 清空槽位字典
        - clarification_count: 重置为0

        注意：只清除状态，不删除消息历史

        Args:
            user_id: 用户ID
            session_id: 会话ID
        """
        # 创建一个空白状态对象（所有字段都是默认值）
        state = ConversationState(
            user_id=user_id,
            session_id=session_id,
            updated_at=datetime.now()
        )

        # 保存空白状态到Redis
        state_key = self._get_state_key(user_id, session_id)
        self.redis_client.setex(
            state_key,
            settings.session_ttl,
            state.model_dump_json()
        )

        agent_logger.info(f"清除对话状态 - 用户: {user_id}, 会话: {session_id}")

    def get_user_sessions(self, user_id: str) -> List[SessionInfo]:
        """
        获取用户的所有会话

        【查询流程】
        1. 从Redis Hash中获取该用户的所有会话ID和基本信息
        2. 遍历每个会话，获取消息数量和最后一条消息
        3. 构建SessionInfo对象列表
        4. 按更新时间降序排序（最近活跃的在前面）

        【Redis数据结构】
        chat:user_sessions:{user_id} 是一个Hash:
        {
            "session_id_1": '{"session_id": "xxx", "created_at": "...", "updated_at": "..."}',
            "session_id_2": '{"session_id": "yyy", "created_at": "...", "updated_at": "..."}',
            ...
        }

        【返回数据】
        SessionInfo包含:
        - session_id: 会话ID
        - user_id: 用户ID
        - created_at: 创建时间
        - updated_at: 最后更新时间
        - message_count: 消息数量
        - last_message: 最后一条消息的前50个字符（用于预览）

        Args:
            user_id: 用户ID

        Returns:
            会话信息列表（按最近活跃排序）
        """
        user_sessions_key = self._get_user_sessions_key(user_id)
        # HGETALL返回Hash中的所有field-value对
        sessions_data = self.redis_client.hgetall(user_sessions_key)

        sessions = []
        for session_id, info_json in sessions_data.items():
            try:
                info = json.loads(info_json)
                # 获取该会话的消息历史，统计消息数量
                history = self.get_chat_history(user_id, session_id)
                messages = history.messages
                message_count = len(messages)
                # 获取最后一条消息用于预览
                last_message = messages[-1].content if messages else None

                sessions.append(SessionInfo(
                    session_id=session_id,
                    user_id=user_id,
                    created_at=datetime.fromisoformat(info["created_at"]),
                    updated_at=datetime.fromisoformat(info["updated_at"]),
                    message_count=message_count,
                    last_message=last_message[:50] if last_message else None  # 截取前50字符
                ))
            except Exception as e:
                agent_logger.error(f"解析会话信息失败: {e}")

        # 按更新时间降序排序（最近活跃的会话排在前面）
        sessions.sort(key=lambda x: x.updated_at, reverse=True)
        return sessions

    def delete_session(self, user_id: str, session_id: str) -> bool:
        """
        删除会话

        【删除流程】
        1. 删除消息历史 (chat:session:{user_id}:{session_id})
        2. 删除对话状态 (chat:state:{user_id}:{session_id})
        3. 从用户会话列表中移除 (HDEL chat:user_sessions:{user_id} {session_id})

        【注意事项】
        - 删除操作是不可逆的
        - 使用try-except保证即使部分删除失败也不会影响其他操作

        【关联数据清理】
        ┌────────────────────────────────────────┐
        │            删除会话                     │
        ├────────────────────────────────────────┤
        │  1. DELETE chat:session:user:session   │ ← 消息历史
        │  2. DELETE chat:state:user:session     │ ← 对话状态
        │  3. HDEL chat:user_sessions:user       │ ← 会话列表条目
        └────────────────────────────────────────┘

        Args:
            user_id: 用户ID
            session_id: 会话ID

        Returns:
            是否删除成功
        """
        try:
            # 1. 删除对话历史（List类型）
            session_key = self._get_session_key(user_id, session_id)
            self.redis_client.delete(session_key)

            # 2. 删除状态（String类型）
            state_key = self._get_state_key(user_id, session_id)
            self.redis_client.delete(state_key)

            # 3. 从用户会话列表中移除（Hash的一个field）
            user_sessions_key = self._get_user_sessions_key(user_id)
            self.redis_client.hdel(user_sessions_key, session_id)

            agent_logger.info(f"删除会话 - 用户: {user_id}, 会话: {session_id}")
            return True
        except Exception as e:
            agent_logger.error(f"删除会话失败: {e}")
            return False

    def _update_session_time(self, user_id: str, session_id: str) -> None:
        """
        更新会话的最后活跃时间

        【更新流程】
        1. 从用户会话列表Hash中获取该会话的信息
        2. 更新updated_at字段为当前时间
        3. 写回Redis

        【用途】
        - 用于前端展示"最近活跃"时间
        - 会话列表排序（按活跃度）
        - 判断会话是否还在活跃中
        """
        user_sessions_key = self._get_user_sessions_key(user_id)
        # 从Hash中获取该session的信息
        session_info_json = self.redis_client.hget(user_sessions_key, session_id)

        if session_info_json:
            session_info = json.loads(session_info_json)
            # 更新最后活跃时间
            session_info["updated_at"] = datetime.now().isoformat()
            # 写回Hash
            self.redis_client.hset(user_sessions_key, session_id, json.dumps(session_info))


# ==================== 全局对话管理器实例 ====================
# 使用单例模式，整个应用共享一个ConversationManager实例
# 这样可以复用Redis连接，避免重复创建连接
#
# 【使用方式】
# from app.services.conversation import conversation_manager
#
# # 创建会话
# session_id = conversation_manager.create_session("user_123")
#
# # 添加消息
# conversation_manager.add_message("user_123", session_id, "user", "我想退货")
#
# # 获取对话历史
# messages = conversation_manager.get_messages("user_123", session_id)
#
# # 更新对话状态
# conversation_manager.update_conversation_state(
#     "user_123", session_id,
#     intent="退货退款",
#     intent_status=IntentStatus.IDENTIFIED
# )
conversation_manager = ConversationManager()
