"""
晨星家居智能客服助手 - 用户管理服务
"""
import hashlib
import secrets
from datetime import datetime
from typing import Optional
from uuid import uuid4

from sqlalchemy.orm import Session

from app.core.logger import agent_logger
from app.models.database import User, SessionLocal


class UserService:
    """用户管理服务"""

    @staticmethod
    def _hash_password(password: str, salt: Optional[str] = None) -> str:
        """
        密码哈希

        Args:
            password: 原始密码
            salt: 盐值，如果不提供则生成新的

        Returns:
            格式为 "salt$hash" 的哈希字符串
        """
        if salt is None:
            salt = secrets.token_hex(16)
        hash_value = hashlib.sha256((salt + password).encode()).hexdigest()
        return f"{salt}${hash_value}"

    @staticmethod
    def _verify_password(password: str, password_hash: str) -> bool:
        """
        验证密码

        Args:
            password: 原始密码
            password_hash: 存储的密码哈希

        Returns:
            密码是否正确
        """
        try:
            salt, stored_hash = password_hash.split("$")
            computed_hash = hashlib.sha256((salt + password).encode()).hexdigest()
            return computed_hash == stored_hash
        except ValueError:
            return False

    def register(
            self,
            username: str,
            password: str,
            nickname: Optional[str] = None,
            email: Optional[str] = None,
            phone: Optional[str] = None
    ) -> dict:
        """
        用户注册

        Args:
            username: 用户名
            password: 密码
            nickname: 昵称
            email: 邮箱
            phone: 手机号

        Returns:
            注册结果
        """
        db: Session = SessionLocal()
        try:
            # 检查用户名是否已存在
            existing_user = db.query(User).filter(User.username == username).first()
            if existing_user:
                return {"success": False, "message": "用户名已存在"}

            # 创建新用户
            user_id = str(uuid4())
            password_hash = self._hash_password(password)

            new_user = User(
                user_id=user_id,
                username=username,
                password_hash=password_hash,
                nickname=nickname or username,
                email=email,
                phone=phone
            )

            db.add(new_user)
            db.commit()
            db.refresh(new_user)

            agent_logger.info(f"用户注册成功 - 用户名: {username}, user_id: {user_id}")

            return {
                "success": True,
                "message": "注册成功",
                "data": {
                    "user_id": user_id,
                    "username": username,
                    "nickname": new_user.nickname
                }
            }
        except Exception as e:
            db.rollback()
            agent_logger.error(f"用户注册失败: {e}")
            return {"success": False, "message": f"注册失败: {str(e)}"}
        finally:
            db.close()

    def login(self, username: str, password: str) -> dict:
        """
        用户登录

        Args:
            username: 用户名
            password: 密码

        Returns:
            登录结果
        """
        db: Session = SessionLocal()
        try:
            user = db.query(User).filter(User.username == username).first()

            if not user:
                return {"success": False, "message": "用户名或密码错误"}

            if not user.is_active:
                return {"success": False, "message": "账户已被禁用"}

            if not self._verify_password(password, user.password_hash):
                return {"success": False, "message": "用户名或密码错误"}

            # 更新最后登录时间
            user.last_login_at = datetime.now()
            db.commit()

            agent_logger.info(f"用户登录成功 - 用户名: {username}, user_id: {user.user_id}")

            return {
                "success": True,
                "message": "登录成功",
                "data": {
                    "user_id": user.user_id,
                    "username": user.username,
                    "nickname": user.nickname,
                    "email": user.email,
                    "phone": user.phone,
                    "avatar": user.avatar
                }
            }
        except Exception as e:
            agent_logger.error(f"用户登录失败: {e}")
            return {"success": False, "message": f"登录失败: {str(e)}"}
        finally:
            db.close()

    def get_user_by_id(self, user_id: str) -> Optional[dict]:
        """
        根据user_id获取用户信息

        Args:
            user_id: 用户ID

        Returns:
            用户信息或None
        """
        db: Session = SessionLocal()
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return None

            return {
                "user_id": user.user_id,
                "username": user.username,
                "nickname": user.nickname,
                "email": user.email,
                "phone": user.phone,
                "avatar": user.avatar,
                "is_active": user.is_active,
                "created_at": user.created_at.isoformat() if user.created_at else None,
                "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None
            }
        finally:
            db.close()

    def update_user(
            self,
            user_id: str,
            nickname: Optional[str] = None,
            email: Optional[str] = None,
            phone: Optional[str] = None,
            avatar: Optional[str] = None
    ) -> dict:
        """
        更新用户信息

        Args:
            user_id: 用户ID
            nickname: 昵称
            email: 邮箱
            phone: 手机号
            avatar: 头像URL

        Returns:
            更新结果
        """
        db: Session = SessionLocal()
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return {"success": False, "message": "用户不存在"}

            if nickname is not None:
                user.nickname = nickname
            if email is not None:
                user.email = email
            if phone is not None:
                user.phone = phone
            if avatar is not None:
                user.avatar = avatar

            db.commit()

            agent_logger.info(f"用户信息更新成功 - user_id: {user_id}")

            return {
                "success": True,
                "message": "更新成功",
                "data": self.get_user_by_id(user_id)
            }
        except Exception as e:
            db.rollback()
            agent_logger.error(f"更新用户信息失败: {e}")
            return {"success": False, "message": f"更新失败: {str(e)}"}
        finally:
            db.close()

    def change_password(self, user_id: str, old_password: str, new_password: str) -> dict:
        """
        修改密码

        Args:
            user_id: 用户ID
            old_password: 旧密码
            new_password: 新密码

        Returns:
            修改结果
        """
        db: Session = SessionLocal()
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return {"success": False, "message": "用户不存在"}

            if not self._verify_password(old_password, user.password_hash):
                return {"success": False, "message": "原密码错误"}

            user.password_hash = self._hash_password(new_password)
            db.commit()

            agent_logger.info(f"用户密码修改成功 - user_id: {user_id}")

            return {"success": True, "message": "密码修改成功"}
        except Exception as e:
            db.rollback()
            agent_logger.error(f"修改密码失败: {e}")
            return {"success": False, "message": f"修改失败: {str(e)}"}
        finally:
            db.close()

    def validate_user(self, user_id: str) -> bool:
        """
        验证用户是否存在且有效

        Args:
            user_id: 用户ID

        Returns:
            用户是否有效
        """
        db: Session = SessionLocal()
        try:
            user = db.query(User).filter(
                User.user_id == user_id,
                User.is_active == True
            ).first()
            return user is not None
        finally:
            db.close()


# 全局用户服务实例
user_service = UserService()
