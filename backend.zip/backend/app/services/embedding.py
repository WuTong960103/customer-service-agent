"""
晨星家居智能客服助手 - 向量化服务
使用LangChain调用本地Ollama的BGE-M3模型进行向量化
"""
from typing import List
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma

from app.core.config import settings
from app.core.logger import agent_logger


class EmbeddingService:
    """
    向量化服务
    封装Ollama BGE-M3模型的调用
    """

    def __init__(self):
        """初始化向量化服务"""
        self.embeddings = OllamaEmbeddings(
            base_url=settings.ollama_base_url,
            model=settings.ollama_embedding_model,
            num_ctx=512,  # 上下文长度
        )
        agent_logger.info(
            f"向量化服务初始化完成，模型: {settings.ollama_embedding_model}"
        )

    def embed_text(self, text: str) -> List[float]:
        """
        将单个文本转换为向量

        Args:
            text: 待向量化的文本

        Returns:
            向量列表
        """
        return self.embeddings.embed_query(text)

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """
        批量将文本转换为向量

        Args:
            texts: 待向量化的文本列表

        Returns:
            向量列表的列表
        """
        return self.embeddings.embed_documents(texts)

    def get_embeddings(self) -> OllamaEmbeddings:
        """
        获取LangChain Embeddings对象

        Returns:
            OllamaEmbeddings对象
        """
        return self.embeddings


class VectorStoreService:
    """
    向量数据库服务
    管理ChromaDB的意图识别和知识库两个独立集合
    """

    def __init__(self, embedding_service: EmbeddingService):
        """
        初始化向量数据库服务

        Args:
            embedding_service: 向量化服务实例
        """
        self.embedding_service = embedding_service

        # 意图识别向量库
        self.intent_store = Chroma(
            collection_name=settings.intent_collection_name,
            embedding_function=embedding_service.get_embeddings(),
            persist_directory=settings.chroma_persist_dir
        )

        # RAG知识库向量库
        self.knowledge_store = Chroma(
            collection_name=settings.knowledge_collection_name,
            embedding_function=embedding_service.get_embeddings(),
            persist_directory=settings.chroma_persist_dir
        )

        agent_logger.info(
            f"向量数据库服务初始化完成，持久化目录: {settings.chroma_persist_dir}"
        )

    def get_intent_store(self) -> Chroma:
        """获取意图识别向量库"""
        return self.intent_store

    def get_knowledge_store(self) -> Chroma:
        """获取知识库向量库"""
        return self.knowledge_store


# 全局服务实例
embedding_service = EmbeddingService()
vector_store_service = VectorStoreService(embedding_service)
