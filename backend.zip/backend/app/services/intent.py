"""
晨星家居智能客服助手 - 意图识别与槽位填充服务

【核心职责】
1. 意图识别：从用户消息中识别出用户的真实意图
2. 槽位提取：提取意图所需的关键信息（如订单号、退款原因等）
3. 槽位完整性检查：判断必填槽位是否都已填充
4. 澄清问题生成：当槽位不完整或意图不明确时，生成追问
5. 意图切换检测：判断用户是否想放弃当前任务，转而询问其他问题

【工作流程】
1. 向量检索：从意图库中检索Top-K相似意图（基于embedding相似度）
2. LLM精确匹配：使用大模型从候选意图中选择最匹配的意图
3. 槽位提取：从用户消息和对话历史中提取槽位值
4. 返回结果：(意图模板, 置信度, 槽位字典)

【技术要点】
- 使用向量数据库加速意图检索
- 结合对话历史理解上下文（处理指代、省略等）
- 支持多轮对话的槽位累积
- 防止过度澄清（最大澄清次数限制）
"""
import json
from typing import List, Optional, Dict, Any, Tuple
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_openai import ChatOpenAI

from app.core.config import settings
from app.core.logger import agent_logger
from app.models.schemas import (
    IntentTemplate,
    SlotInfo,
    IntentStatus,
    ResolutionMethod,
    ConversationState
)
from app.services.embedding import vector_store_service


class IntentRecognitionService:
    """
    意图识别服务
    负责识别用户意图、提取槽位信息、判断是否需要澄清

    【核心方法】
    - recognize_intent: 主流程，识别意图并提取槽位
    - check_slots_completion: 检查槽位是否填充完整
    - generate_clarification: 生成澄清问题
    - check_intent_switch: 检测用户是否想切换意图
    """

    def __init__(self):
        """
        初始化意图识别服务

        【配置说明】
        - temperature=0.1: 低温度使输出更稳定、确定性更强（意图识别需要准确性）
        - 使用通义千问模型（settings中配置）
        """
        self.llm = ChatOpenAI(
            api_key=settings.qwen_api_key,
            base_url=settings.qwen_base_url,
            model=settings.qwen_model_name,
            temperature=0.1  # 低温度，确保意图识别的稳定性
        )
        agent_logger.info("意图识别服务初始化完成")

    def _get_intent_store(self):
        """
        获取最新的意图向量库实例

        【设计原因】
        不在__init__中缓存意图库，而是每次动态获取，确保：
        - 意图库更新后能立即生效（支持热更新）
        - 避免旧实例引用过时的数据
        """
        return vector_store_service.get_intent_store()

    async def get_intent_by_name(self, intent_name: str) -> Optional[IntentTemplate]:
        """
        根据意图名称获取意图模板

        【使用场景】
        当用户在澄清槽位时，我们需要根据已存储的意图名称恢复完整的意图模板。

        【查找策略】
        1. 使用意图名称进行向量搜索（而非精确匹配）
        2. 从返回的Top-5结果中，找到intent_name完全匹配的
        3. 支持从文档内容或metadata中解析意图数据

        Args:
            intent_name: 意图名称

        Returns:
            意图模板，如果未找到返回None
        """
        intent_store = self._get_intent_store()

        # 使用意图名称进行向量搜索（返回Top-5相似文档）
        results = intent_store.similarity_search_with_score(intent_name, k=5)

        # 遍历搜索结果，找到名称完全匹配的意图
        for doc, score in results:
            try:
                # 尝试直接解析page_content为JSON（意图模板文档）
                intent_data = json.loads(doc.page_content)
                if intent_data.get("intent_name") == intent_name:
                    # 找到匹配的意图，构造IntentTemplate对象
                    return IntentTemplate(
                        intent_name=intent_data.get("intent_name", ""),
                        intent_description=intent_data.get("intent_description", ""),
                        slots=[SlotInfo(**s) for s in intent_data.get("slots", [])],
                        resolution_method=ResolutionMethod(intent_data.get("resolution_method", "rag")),
                        example_queries=intent_data.get("example_queries", [])
                    )
            except json.JSONDecodeError:
                # 如果page_content不是JSON（可能是示例话术文档）
                # 尝试从metadata中获取完整意图
                if doc.metadata.get("intent_name") == intent_name and doc.metadata.get("full_intent"):
                    try:
                        intent_data = json.loads(doc.metadata["full_intent"])
                        return IntentTemplate(
                            intent_name=intent_data.get("intent_name", ""),
                            intent_description=intent_data.get("intent_description", ""),
                            slots=[SlotInfo(**s) for s in intent_data.get("slots", [])],
                            resolution_method=ResolutionMethod(intent_data.get("resolution_method", "rag")),
                            example_queries=intent_data.get("example_queries", [])
                        )
                    except json.JSONDecodeError:
                        continue  # 解析失败，继续下一个文档

        # 所有结果都未匹配
        agent_logger.warning(f"未找到意图模板: {intent_name}")
        return None

    async def check_intent_switch(
            self,
            user_message: str,
            current_intent: str,
            conversation_history: List[Dict[str, str]]
    ) -> Tuple[bool, Optional[str]]:
        """
        检查用户是否想要切换意图（放弃当前意图）

        【使用场景】
        当系统正在澄清槽位时，用户可能：
        - 放弃当前任务："算了，我不退货了"
        - 切换到新问题："先不说这个，我想问一下发票怎么开"

        【检测策略】
        1. 关键词快速过滤：检查是否包含放弃/切换关键词
        2. LLM精确判断：使用大模型分析用户是否真的想切换

        Args:
            user_message: 用户消息
            current_intent: 当前意图名称
            conversation_history: 对话历史

        Returns:
            (是否切换意图, 切换原因)
        """
        # 常见的放弃/切换意图的关键词列表
        switch_keywords = [
            "不想", "不要了", "算了", "取消", "放弃", "换个", "另外",
            "先不", "暂时不", "不用了", "别的", "其他", "还是",
            "不处理", "不办", "不开", "不查", "不退", "不改",
            "先问", "想问", "想知道", "请告诉", "请问"
        ]

        # 快速检查是否包含切换关键词
        has_switch_keyword = any(kw in user_message for kw in switch_keywords)

        # 如果没有明确的切换关键词，检查是否有疑问词（可能是新问题）
        if not has_switch_keyword:
            # 疑问词列表
            question_indicators = ["？", "?", "吗", "呢", "哪些", "什么", "怎么", "如何", "多少"]
            has_question = any(q in user_message for q in question_indicators)
            if not has_question:
                # 既无切换关键词，又无疑问词，大概率是在补充槽位
                return False, None

        # 使用LLM进行精确判断（避免误判）
        prompt = ChatPromptTemplate.from_messages([
            ("system", """你是一个意图切换检测器。判断用户是否想要放弃当前正在进行的操作，转而询问其他问题。

【判断标准】
- 明确的放弃词："算了"、"不要了"、"取消" → 切换
- 新话题引入："我想问"、"请问"、"另外" → 切换
- 补充信息："15812345678"、"质量问题" → 不切换

返回JSON格式:
{
    "wants_to_switch": true/false,
    "reason": "判断理由"
}"""),
            ("human", """当前正在处理的意图: {current_intent}

用户最新消息: {message}

请判断用户是否想要放弃当前操作，转而询问其他问题:""")
        ])

        # 构建Chain：prompt → LLM → JSON解析器
        chain = prompt | self.llm | JsonOutputParser()

        try:
            # 异步调用LLM进行判断
            result = await chain.ainvoke({
                "current_intent": current_intent,
                "message": user_message
            })
            wants_switch = result.get("wants_to_switch", False)
            reason = result.get("reason", "")
            agent_logger.info(f"意图切换检测: wants_switch={wants_switch}, reason={reason}")
            return wants_switch, reason
        except Exception as e:
            agent_logger.error(f"意图切换检测失败: {e}")
            # 如果LLM调用失败，降级为基于关键词的简单判断
            return has_switch_keyword, "基于关键词判断"

    async def extract_slots_only(
            self,
            user_message: str,
            intent: IntentTemplate,
            conversation_history: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        仅提取槽位值（不做意图识别）

        【使用场景】
        当用户正在澄清槽位时，意图已经明确，只需要从新消息中提取槽位值。

        【提取原则】
        - 只提取用户明确提供的值，不猜测或推断
        - 结合对话历史理解上下文（处理指代）
        - 返回字典格式：{"槽位名": "槽位值"}

        Args:
            user_message: 用户消息
            intent: 当前意图模板
            conversation_history: 对话历史

        Returns:
            提取的槽位值字典
        """
        agent_logger.info(f"仅提取槽位，意图: {intent.intent_name}")

        # 构建对话历史
        history_text = ""
        if conversation_history:
            history_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else '客服'}: {msg['content']}"
                for msg in conversation_history[-4:]
            ])

        # 槽位信息
        slots_info = "\n".join([
            f"- {slot.name}: {slot.description}"
            for slot in intent.slots
        ])

        prompt = ChatPromptTemplate.from_messages([
            ("system", """你是一个槽位提取器。根据对话历史和用户最新消息，提取用户提供的槽位值。
只需要提取用户明确提供的值，不要猜测或推断。
返回JSON格式: {{"槽位名称": "槽位值", ...}}
如果用户没有提供某个槽位的值，不要包含在结果中。"""),
            ("human", """对话历史:
{history}

当前意图: {intent_name}

需要提取的槽位:
{slots}

用户最新消息: {message}

请提取槽位值（JSON格式）:""")
        ])

        chain = prompt | self.llm | JsonOutputParser()

        try:
            result = await chain.ainvoke({
                "history": history_text or "无",
                "intent_name": intent.intent_name,
                "slots": slots_info,
                "message": user_message
            })
            agent_logger.info(f"槽位提取结果: {result}")
            return result if isinstance(result, dict) else {}
        except Exception as e:
            agent_logger.error(f"槽位提取失败: {e}")
            return {}

    async def recognize_intent(
            self,
            user_message: str,
            conversation_history: List[Dict[str, str]],
            current_state: Optional[ConversationState] = None
    ) -> Tuple[Optional[IntentTemplate], float, Dict[str, Any]]:
        """
        识别用户意图 - 核心入口方法

        【完整流程】
        ┌─────────────────────────────────────────────────────────────┐
        │  用户消息: "我想退掉上周买的那个沙发"                           │
        └─────────────────────────────────────────────────────────────┘
                                    ↓
        ┌─────────────────────────────────────────────────────────────┐
        │  Step 1: 向量检索 (similarity_search_with_score)            │
        │  - 将用户消息转为向量                                         │
        │  - 从意图库中检索Top-K相似的意图文档                           │
        │  - 返回: [(doc1, score1), (doc2, score2), ...]              │
        └─────────────────────────────────────────────────────────────┘
                                    ↓
        ┌─────────────────────────────────────────────────────────────┐
        │  Step 2: 解析候选意图                                        │
        │  - 将检索到的文档解析为IntentTemplate对象                      │
        │  - 处理两种文档格式:                                          │
        │    a) 意图定义文档 (page_content是JSON)                       │
        │    b) 示例话术文档 (从metadata获取full_intent)                │
        └─────────────────────────────────────────────────────────────┘
                                    ↓
        ┌─────────────────────────────────────────────────────────────┐
        │  Step 3: LLM精确匹配 (_match_intent_with_llm)               │
        │  - 将候选意图、对话历史、用户消息发给LLM                        │
        │  - LLM分析后返回:                                            │
        │    a) 最匹配的意图索引                                        │
        │    b) 置信度 (0-1)                                           │
        │    c) 提取的槽位值                                           │
        └─────────────────────────────────────────────────────────────┘
                                    ↓
        ┌─────────────────────────────────────────────────────────────┐
        │  返回: (IntentTemplate, confidence, extracted_slots)         │
        │  例如: (退货退款意图, 0.95, {"product_name": "沙发"})          │
        └─────────────────────────────────────────────────────────────┘

        Args:
            user_message: 用户消息
            conversation_history: 对话历史 (用于理解上下文、处理指代)
            current_state: 当前对话状态 (包含已识别意图和已填充槽位)

        Returns:
            (意图模板, 置信度, 提取的槽位值)
            - 意图模板: 匹配的IntentTemplate对象，无匹配时为None
            - 置信度: 0-1之间的浮点数，表示匹配确信程度
            - 槽位值: {"slot_name": "slot_value"} 字典
        """
        agent_logger.info(f"开始识别意图，用户消息: {user_message}")

        # ==================== Step 1: 向量检索 ====================
        # 从向量库中检索相似意图（每次获取最新的store，支持热更新）
        intent_store = self._get_intent_store()

        # 调试：打印当前意图库中的文档数量
        try:
            doc_count = intent_store._collection.count()
            agent_logger.info(f"意图库文档数量: {doc_count}")
        except Exception as e:
            agent_logger.error(f"获取意图库数量失败: {e}")

        # 执行向量相似度搜索
        # k=3: 返回Top-3相似的文档
        # 返回格式: [(Document, score), ...] 其中score越小越相似（距离）
        similar_intents = intent_store.similarity_search_with_score(
            user_message,
            k=3
        )

        agent_logger.info(f"向量检索返回 {len(similar_intents)} 条结果")

        # 如果没有检索到任何相似意图，直接返回
        if not similar_intents:
            agent_logger.warning("未找到相似意图")
            return None, 0.0, {}

        # ==================== Step 2: 解析候选意图 ====================
        # 将检索到的文档解析为可用的意图数据结构
        intent_candidates = []
        for doc, score in similar_intents:
            agent_logger.debug(f"检索到文档: score={score}, content={doc.page_content[:100]}..., metadata={doc.metadata}")

            try:
                # 尝试解析方式A: 文档内容本身就是意图JSON
                # 这是意图定义文档的格式
                intent_data = json.loads(doc.page_content)
                intent_candidates.append({
                    "intent": intent_data,
                    "similarity_score": 1 - score  # 将距离转换为相似度(0-1)
                })
                agent_logger.info(f"成功解析意图JSON: {intent_data.get('intent_name', 'unknown')}")
            except json.JSONDecodeError:
                # 尝试解析方式B: 从metadata中获取完整意图
                # 这是示例话术文档的格式（page_content是示例句子，完整意图存在metadata）
                if doc.metadata.get("type") == "example" and doc.metadata.get("full_intent"):
                    try:
                        intent_data = json.loads(doc.metadata["full_intent"])
                        # 去重检查：避免同一个意图被多次添加
                        existing_names = [c["intent"].get("intent_name") for c in intent_candidates]
                        if intent_data.get("intent_name") not in existing_names:
                            intent_candidates.append({
                                "intent": intent_data,
                                "similarity_score": 1 - score
                            })
                            agent_logger.info(f"从示例话术metadata中获取意图: {intent_data.get('intent_name', 'unknown')}")
                    except json.JSONDecodeError:
                        agent_logger.warning(f"无法解析metadata中的full_intent: {doc.metadata.get('full_intent', '')[:50]}")
                else:
                    agent_logger.warning(f"无法解析文档为JSON且无full_intent metadata: {doc.page_content[:50]}...")

        # 如果所有文档都无法解析，返回空结果
        if not intent_candidates:
            agent_logger.warning("所有检索到的文档都无法解析为有效意图")
            return None, 0.0, {}

        agent_logger.info(f"成功解析 {len(intent_candidates)} 个候选意图")

        # ==================== Step 3: LLM精确匹配 ====================
        # 使用大模型从候选意图中选择最匹配的，并提取槽位
        matched_intent, confidence, extracted_slots = await self._match_intent_with_llm(
            user_message,
            conversation_history,
            intent_candidates,
            current_state
        )

        return matched_intent, confidence, extracted_slots

    async def _match_intent_with_llm(
            self,
            user_message: str,
            conversation_history: List[Dict[str, str]],
            intent_candidates: List[Dict[str, Any]],
            current_state: Optional[ConversationState]
    ) -> Tuple[Optional[IntentTemplate], float, Dict[str, Any]]:
        """
        使用LLM精确匹配意图并提取槽位

        【为什么需要LLM精确匹配？】
        向量检索是基于语义相似度的"粗筛"，可能返回多个相似意图。
        例如: "我想退货" 可能同时匹配 "退货退款"、"换货" 等意图。
        需要LLM结合上下文进行"精选"，确定最准确的意图。

        【LLM的任务】
        1. 分析用户消息的真实意图
        2. 结合对话历史理解上下文（处理"它"、"这个"等指代）
        3. 从候选意图中选择最匹配的一个
        4. 同时提取槽位值（一次LLM调用完成多个任务）
        5. 给出置信度评分

        【输入数据准备】
        - history_text: 最近6轮对话，用于理解上下文
        - candidates_text: 候选意图的详细信息（名称、描述、槽位、示例）
        - state_text: 当前对话状态（已识别意图、已填槽位）

        Args:
            user_message: 用户消息
            conversation_history: 对话历史
            intent_candidates: 候选意图列表，格式: [{"intent": {...}, "similarity_score": 0.9}, ...]
            current_state: 当前对话状态

        Returns:
            (匹配的意图模板, 置信度, 提取的槽位值)
        """
        # ==================== 准备输入数据 ====================

        # 1. 构建对话历史文本（最近6轮，避免上下文过长）
        history_text = ""
        if conversation_history:
            history_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else '客服'}: {msg['content']}"
                for msg in conversation_history[-6:]  # 最近6轮对话
            ])

        # 2. 构建候选意图信息（供LLM选择）
        candidates_text = ""
        for idx, candidate in enumerate(intent_candidates):
            intent = candidate["intent"]
            candidates_text += f"""
意图{idx + 1}:
- 意图名称: {intent.get('intent_name', '')}
- 意图描述: {intent.get('intent_description', '')}
- 关键槽位: {json.dumps(intent.get('slots', []), ensure_ascii=False)}
- 示例话术: {', '.join(intent.get('example_queries', [])[:3])}
- 相似度: {candidate['similarity_score']:.2f}
"""

        # 3. 构建当前状态信息（如果有）
        state_text = ""
        if current_state and current_state.current_intent:
            state_text = f"""
当前对话状态:
- 已识别意图: {current_state.current_intent}
- 已填充槽位: {json.dumps({k: v.model_dump() for k, v in current_state.slots.items()}, ensure_ascii=False)}
"""

        # ==================== 构建Prompt并调用LLM ====================
        prompt = ChatPromptTemplate.from_messages([
            ("system", """你是晨星家居智能客服的意图识别模块。你的任务是：
1. 分析用户当前消息和对话历史
2. 从候选意图中选择最匹配的意图
3. 提取用户消息中的槽位信息
4. 判断意图识别的置信度

注意事项：
- 如果用户消息中存在指示代词（如"它"、"这个"、"那个"）或省略主语，需要结合对话历史理解
- 如果用户消息模糊不清，置信度应该降低
- 如果没有匹配的意图，返回null

请以JSON格式返回结果。"""),
            ("human", """对话历史:
{history}

当前用户消息: {message}

候选意图:
{candidates}

{state}

请分析并返回JSON格式结果:
{{
    "matched_intent_index": <匹配的意图索引(1开始)，如果无匹配则为null>,
    "confidence": <置信度0-1>,
    "extracted_slots": {{
        "槽位名称": "槽位值"
    }},
    "reasoning": "分析理由",
    "needs_clarification": <是否需要澄清，true/false>,
    "clarification_question": "如果需要澄清，这里是澄清问题"
}}""")
        ])

        # 构建Chain: Prompt → LLM → JSON解析器
        chain = prompt | self.llm | JsonOutputParser()

        try:
            # 异步调用LLM
            result = await chain.ainvoke({
                "history": history_text or "无",
                "message": user_message,
                "candidates": candidates_text,
                "state": state_text or "无"
            })

            agent_logger.info(f"LLM意图匹配结果: {result}")

            # ==================== 解析LLM返回结果 ====================
            matched_index = result.get("matched_intent_index")  # 匹配的意图索引(1-based)
            confidence = result.get("confidence", 0.0)          # 置信度
            extracted_slots = result.get("extracted_slots", {}) # 提取的槽位

            # 如果有匹配的意图，构造IntentTemplate对象返回
            if matched_index and 1 <= matched_index <= len(intent_candidates):
                intent_data = intent_candidates[matched_index - 1]["intent"]
                matched_intent = IntentTemplate(
                    intent_name=intent_data.get("intent_name", ""),
                    intent_description=intent_data.get("intent_description", ""),
                    slots=[SlotInfo(**s) for s in intent_data.get("slots", [])],
                    resolution_method=ResolutionMethod(intent_data.get("resolution_method", "rag")),
                    example_queries=intent_data.get("example_queries", [])
                )
                return matched_intent, confidence, extracted_slots

            # 没有匹配的意图
            return None, confidence, extracted_slots

        except Exception as e:
            agent_logger.error(f"LLM意图匹配失败: {e}")
            return None, 0.0, {}

    async def check_slots_completion(
            self,
            intent: IntentTemplate,
            filled_slots: Dict[str, Any]
    ) -> Tuple[bool, List[SlotInfo]]:
        """
        检查槽位是否填充完整

        【槽位填充机制说明】
        意图模板中定义了多个槽位(slots)，每个槽位有:
        - name: 槽位名称 (如 "order_id", "refund_reason")
        - required: 是否必填
        - description: 槽位描述

        只有当所有必填槽位都被填充后，才能执行意图对应的操作。

        【示例】
        意图: 退货退款
        槽位定义:
          - order_id (必填): 订单号
          - refund_reason (必填): 退款原因
          - refund_method (可选): 退款方式

        已填槽位: {"order_id": "12345"}
        检查结果: (False, [refund_reason槽位])  # 缺少退款原因

        Args:
            intent: 意图模板（包含槽位定义）
            filled_slots: 已填充的槽位字典 {"槽位名": "槽位值"}

        Returns:
            (是否完整, 缺失的必填槽位列表)
        """
        missing_slots = []

        # 遍历意图模板中定义的所有槽位
        for slot in intent.slots:
            # 只检查必填槽位，可选槽位不影响完整性判断
            if slot.required and slot.name not in filled_slots:
                missing_slots.append(slot)

        is_complete = len(missing_slots) == 0
        agent_logger.info(
            f"槽位完整性检查 - 意图: {intent.intent_name}, "
            f"完整: {is_complete}, 缺失: {[s.name for s in missing_slots]}"
        )

        return is_complete, missing_slots

    async def generate_clarification(
            self,
            user_message: str,
            intent: Optional[IntentTemplate],
            missing_slots: List[SlotInfo],
            conversation_history: List[Dict[str, str]]
    ) -> str:
        """
        生成澄清问题

        【使用场景】
        1. 意图已识别但槽位不完整 → 追问缺失的槽位信息
        2. 意图未识别（置信度低） → 引导用户明确需求

        【设计原则】
        - 一次性询问所有缺失信息（避免多轮追问导致用户体验差）
        - 语气亲切友好
        - 提供选项或示例帮助用户理解
        - 有降级方案（LLM失败时使用模板）

        【示例】
        场景1: 用户说"我要退货"，缺少订单号和退款原因
        生成: "好的，为了帮您处理退货，请提供以下信息：
               1. 您的订单号是多少？
               2. 退货原因是什么（如质量问题、尺寸不合适等）？"

        场景2: 用户说"帮帮我"，意图不明确
        生成: "您好，请问您需要什么帮助？
               是想咨询商品信息、查询订单、还是需要售后服务呢？"

        Args:
            user_message: 用户消息
            intent: 当前意图（可能为None，表示意图不明确）
            missing_slots: 缺失的槽位列表
            conversation_history: 对话历史

        Returns:
            澄清问题文本
        """
        agent_logger.info("生成澄清问题")

        # 构建对话历史（最近4轮，用于理解上下文）
        history_text = ""
        if conversation_history:
            history_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else '客服'}: {msg['content']}"
                for msg in conversation_history[-4:]
            ])

        if intent:
            # ==================== 情况1: 有意图但槽位不完整 ====================
            # 构建缺失槽位信息
            slots_info = "\n".join([
                f"- {slot.name}: {slot.description}"
                for slot in missing_slots
            ])

            prompt = ChatPromptTemplate.from_messages([
                ("system", """你是晨星家居的智能客服助手。用户的意图已经识别，但缺少一些必要信息。
请生成一个友好、自然的追问，引导用户提供缺失的信息。

要求：
1. 语气亲切友好
2. 一次性询问所有缺失的信息，不要分多次询问
3. 如果有多个缺失信息，用清晰的格式列出（如编号列表）
4. 如果可能，提供选项或示例帮助用户理解
5. 保持简洁，不要过于冗长"""),
                ("human", """对话历史:
{history}

用户最新消息: {message}

已识别意图: {intent_name} - {intent_desc}

缺失的必要信息:
{missing_slots}

请生成一个澄清问题（一次性询问所有缺失信息）:""")
            ])

            chain = prompt | self.llm

            try:
                response = await chain.ainvoke({
                    "history": history_text or "无",
                    "message": user_message,
                    "intent_name": intent.intent_name,
                    "intent_desc": intent.intent_description,
                    "missing_slots": slots_info
                })
                return response.content
            except Exception as e:
                agent_logger.error(f"生成澄清问题失败: {e}")
                # 降级方案：使用模板生成澄清问题
                if len(missing_slots) == 1:
                    return f"请问您能告诉我{missing_slots[0].description}吗？"
                else:
                    slots_list = "、".join([s.description for s in missing_slots])
                    return f"为了更好地帮助您，请提供以下信息：{slots_list}"

        else:
            # ==================== 情况2: 无法识别意图 ====================
            prompt = ChatPromptTemplate.from_messages([
                ("system", """你是晨星家居的智能客服助手。用户的意图不够明确，需要进一步澄清。
请生成一个友好的追问，帮助理解用户真正想要什么。

要求：
1. 语气亲切友好
2. 根据用户消息中的关键词进行追问
3. 可以提供可能的选项供用户选择
4. 保持简洁"""),
                ("human", """对话历史:
{history}

用户最新消息: {message}

请生成一个澄清问题，帮助理解用户的真实需求:""")
            ])

            chain = prompt | self.llm

            try:
                response = await chain.ainvoke({
                    "history": history_text or "无",
                    "message": user_message
                })
                return response.content
            except Exception as e:
                agent_logger.error(f"生成澄清问题失败: {e}")
                # 降级方案：使用通用模板
                return "抱歉，我不太理解您的意思。请问您是想咨询商品信息、查询订单、还是需要售后帮助呢？"


# ==================== 全局服务实例 ====================
# 使用单例模式，整个应用共享一个IntentRecognitionService实例
# 这样可以复用LLM连接，避免重复初始化
intent_service = IntentRecognitionService()
