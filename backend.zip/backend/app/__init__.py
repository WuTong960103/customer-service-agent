"""
晨星家居智能客服助手 - 应用模块
"""
from app.main import app

__all__ = ["app"]
