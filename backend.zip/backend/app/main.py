"""
晨星家居智能客服助手 - FastAPI应用主入口
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logger import logger
from app.api import api_router
from app.models.database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时
    logger.info("=" * 60)
    logger.info("晨星家居智能客服助手 启动中...")
    logger.info(f"API服务地址: http://{settings.api_host}:{settings.api_port}")
    logger.info(f"Qwen模型: {settings.qwen_model_name}")
    logger.info(f"向量化模型: {settings.ollama_embedding_model}")

    # 初始化数据库
    try:
        init_db()
        logger.info("MySQL数据库初始化成功")
    except Exception as e:
        logger.error(f"MySQL数据库初始化失败: {e}")

    logger.info("=" * 60)

    yield

    # 关闭时
    logger.info("晨星家居智能客服助手 已关闭")


# 创建FastAPI应用
app = FastAPI(
    title="晨星家居智能客服助手",
    description="基于LangChain和Qwen大模型的智能客服系统",
    version="1.0.0",
    lifespan=lifespan
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 开发环境允许所有来源
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(api_router)


@app.get("/")
async def root():
    """根路由"""
    return {
        "name": "晨星家居智能客服助手",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy"}
