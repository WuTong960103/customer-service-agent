"""
晨星家居智能客服助手 - 示例数据生成脚本
生成意图模板和知识库的Excel示例文件
"""
import json
import pandas as pd
from pathlib import Path


def create_intent_template_excel():
    """创建意图模板Excel示例文件"""
    intents = [
        {
            "intent_name": "查询订单",
            "intent_description": "用户想要查询订单状态、订单详情等信息",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": True}
            ], ensure_ascii=False),
            "resolution_method": "function_call",
            "example_queries": "查询订单|我的订单在哪里|订单状态|帮我查一下订单|我想看看我的订单"
        },
        {
            "intent_name": "物流查询",
            "intent_description": "用户想要查询物流信息、快递进度",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": True}
            ], ensure_ascii=False),
            "resolution_method": "function_call",
            "example_queries": "物流在哪|快递到哪了|什么时候能收到货|查物流|物流信息"
        },
        {
            "intent_name": "退货退款",
            "intent_description": "用户想要申请退货或退款",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": True},
                {"name": "reason", "description": "退货原因", "required": True}
            ], ensure_ascii=False),
            "resolution_method": "function_call",
            "example_queries": "我要退货|申请退款|不想要了|退货退款|商品有问题想退"
        },
        {
            "intent_name": "修改地址",
            "intent_description": "用户想要修改收货地址或发票地址",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": True},
                {"name": "address_type", "description": "地址类型(收货地址/发票地址)", "required": True},
                {"name": "new_address", "description": "新地址", "required": True}
            ], ensure_ascii=False),
            "resolution_method": "function_call",
            "example_queries": "修改地址|改一下收货地址|我想换个地址|地址写错了"
        },
        {
            "intent_name": "发票申请",
            "intent_description": "用户想要申请发票或修改发票信息",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": True},
                {"name": "invoice_type", "description": "发票类型(个人/企业)", "required": True},
                {"name": "invoice_title", "description": "发票抬头", "required": True}
            ], ensure_ascii=False),
            "resolution_method": "function_call",
            "example_queries": "开发票|我要发票|申请发票|能开发票吗|发票怎么开"
        },
        {
            "intent_name": "产品咨询",
            "intent_description": "用户咨询产品信息、规格、材质等",
            "slots": json.dumps([
                {"name": "product_name", "description": "产品名称", "required": False}
            ], ensure_ascii=False),
            "resolution_method": "rag",
            "example_queries": "这个桌子是什么材质|产品尺寸是多少|有什么颜色|产品详情"
        },
        {
            "intent_name": "售后政策咨询",
            "intent_description": "用户咨询退换货政策、保修政策等",
            "slots": json.dumps([], ensure_ascii=False),
            "resolution_method": "rag",
            "example_queries": "退货政策|几天内可以退|保修多久|售后服务|怎么保修"
        },
        {
            "intent_name": "配送咨询",
            "intent_description": "用户咨询配送范围、配送时间、运费等",
            "slots": json.dumps([], ensure_ascii=False),
            "resolution_method": "rag",
            "example_queries": "运费多少|配送到哪里|几天能到|包邮吗|送货上门吗"
        },
        {
            "intent_name": "安装服务",
            "intent_description": "用户咨询产品安装服务",
            "slots": json.dumps([
                {"name": "order_id", "description": "订单号", "required": False}
            ], ensure_ascii=False),
            "resolution_method": "rag",
            "example_queries": "怎么安装|有安装服务吗|安装费用|上门安装|安装说明"
        },
        {
            "intent_name": "转人工服务",
            "intent_description": "用户想要转接人工客服",
            "slots": json.dumps([], ensure_ascii=False),
            "resolution_method": "human",
            "example_queries": "转人工|人工客服|找人工|我要找人|真人客服"
        }
    ]

    df = pd.DataFrame(intents)
    return df


def create_knowledge_excel():
    """创建知识库Excel示例文件"""
    knowledge = [
        # 退换货政策
        {
            "category": "售后政策",
            "topic": "退货政策",
            "question": "购买的商品可以退货吗？退货期限是多久？",
            "answer": "晨星家居支持7天无理由退货。自签收之日起7天内，商品保持原包装、未使用、不影响二次销售的情况下，可申请无理由退货。大件家具因物流特殊性，请在签收时当场验货，如有问题请当场拒收。"
        },
        {
            "category": "售后政策",
            "topic": "换货政策",
            "question": "商品有质量问题怎么换货？",
            "answer": "商品存在质量问题，自签收之日起15天内可申请换货。请提供商品问题照片，客服审核通过后会安排换货。换货运费由晨星家居承担。"
        },
        {
            "category": "售后政策",
            "topic": "退款时效",
            "question": "退款需要多长时间到账？",
            "answer": "退货商品到达仓库并验收通过后，退款将在3-5个工作日内原路退回到您的支付账户。银行处理时间可能略有差异。"
        },
        # 配送信息
        {
            "category": "配送信息",
            "topic": "配送范围",
            "question": "你们配送范围是哪些地区？",
            "answer": "晨星家居支持全国配送（港澳台及偏远地区除外）。大件家具配送至全国主要城市，偏远地区可能需要额外配送时间。"
        },
        {
            "category": "配送信息",
            "topic": "配送时间",
            "question": "下单后多久可以收到货？",
            "answer": "现货商品：一般3-7个工作日送达（偏远地区7-15天）。定制/预售商品：根据商品详情页标注的发货时间，大件家具因需要物流中转，配送时间稍长，具体以物流信息为准。"
        },
        {
            "category": "配送信息",
            "topic": "运费说明",
            "question": "运费怎么计算？多少钱包邮？",
            "answer": "订单金额满199元即可享受包邮服务（偏远地区除外）。不满199元的订单收取10元运费。大件家具统一包邮，含送货上门服务。"
        },
        # 产品信息
        {
            "category": "产品信息",
            "topic": "材质说明",
            "question": "你们的实木家具是什么材质？",
            "answer": "晨星家居的实木家具主要采用北美进口白橡木、北欧白蜡木、新西兰松木等优质木材。所有木材经过严格筛选和处理，符合国家环保标准。板材家具采用E0级环保板材。"
        },
        {
            "category": "产品信息",
            "topic": "尺寸定制",
            "question": "家具可以定制尺寸吗？",
            "answer": "部分产品支持尺寸定制服务，定制周期一般为15-30个工作日。定制产品不支持无理由退货，请确认好尺寸后再下单。如需定制，请联系客服咨询具体产品是否支持定制。"
        },
        # 安装服务
        {
            "category": "安装服务",
            "topic": "安装服务",
            "question": "大件家具有安装服务吗？怎么收费？",
            "answer": "晨星家居提供大件家具免费上门安装服务，覆盖全国300+城市。安装师傅会在配送后1-3天内联系您预约安装时间。小件家具均附有详细安装说明书，可自行安装。"
        },
        {
            "category": "安装服务",
            "topic": "安装预约",
            "question": "怎么预约安装服务？",
            "answer": "大件家具配送后，我们的安装合作伙伴会在1-3个工作日内主动联系您预约安装时间。如超过3天未收到联系，请拨打客服热线400-XXX-XXXX或联系在线客服，我们会为您协调安排。"
        },
        # 发票相关
        {
            "category": "发票服务",
            "topic": "发票申请",
            "question": "怎么申请发票？",
            "answer": "晨星家居支持开具电子发票和纸质发票。订单完成后，可在'我的订单'中申请开票，或联系客服申请。电子发票将发送至您的邮箱，纸质发票将在开具后7个工作日内寄出。"
        },
        {
            "category": "发票服务",
            "topic": "发票类型",
            "question": "可以开什么类型的发票？",
            "answer": "支持开具增值税普通发票（个人/企业）和增值税专用发票（仅限企业）。增值税专用发票需提供企业全称、税号、开户行及账号、注册地址及电话。"
        },
        # 售后维修
        {
            "category": "售后服务",
            "topic": "保修政策",
            "question": "产品保修期是多久？",
            "answer": "晨星家居产品享受以下保修服务：实木家具：主体框架保修3年，五金配件保修1年；板式家具：整体保修2年；软体家具：框架保修3年，面料保修1年。保修期内非人为损坏可享受免费维修服务。"
        },
        {
            "category": "售后服务",
            "topic": "维修服务",
            "question": "产品过了保修期坏了怎么办？",
            "answer": "保修期外的产品维修，我们提供有偿维修服务。请联系客服描述问题，我们会根据情况提供维修方案和报价。部分配件可单独购买，运费由客户承担。"
        }
    ]

    df = pd.DataFrame(knowledge)
    return df


def main():
    """生成示例数据文件"""
    # 确保data目录存在
    data_dir = Path(__file__).parent.parent / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    # 生成意图模板Excel
    intent_df = create_intent_template_excel()
    intent_path = data_dir / "intent_templates.xlsx"
    intent_df.to_excel(intent_path, index=False)
    print(f"意图模板文件已生成: {intent_path}")

    # 生成知识库Excel
    knowledge_df = create_knowledge_excel()
    knowledge_path = data_dir / "knowledge_base.xlsx"
    knowledge_df.to_excel(knowledge_path, index=False)
    print(f"知识库文件已生成: {knowledge_path}")


if __name__ == "__main__":
    main()
