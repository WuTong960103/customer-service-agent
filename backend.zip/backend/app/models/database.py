"""
晨星家居智能客服助手 - 数据库模型定义
使用SQLAlchemy ORM管理MySQL数据库
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import create_engine, String, DateTime, Boolean, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from app.core.config import settings


class Base(DeclarativeBase):
    """SQLAlchemy基类"""
    pass


class User(Base):
    """用户表"""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(String(64), unique=True, index=True, comment="用户唯一标识")
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, comment="用户名")
    password_hash: Mapped[str] = mapped_column(String(256), comment="密码哈希")
    nickname: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, comment="昵称")
    email: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, comment="邮箱")
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True, comment="手机号")
    avatar: Mapped[Optional[str]] = mapped_column(String(256), nullable=True, comment="头像URL")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, comment="是否激活")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, comment="创建时间")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, comment="最后登录时间")

    def __repr__(self) -> str:
        return f"<User(user_id={self.user_id}, username={self.username})>"


# 创建数据库引擎
engine = create_engine(
    settings.mysql_url,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

# 创建会话工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """初始化数据库，创建所有表"""
    Base.metadata.create_all(bind=engine)


def get_db():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
