"""
晨星家居智能客服助手 - 数据模型定义
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


class MessageRole(str, Enum):
    """消息角色"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class IntentStatus(str, Enum):
    """意图状态"""
    IDENTIFIED = "identified"  # 已识别
    CLARIFYING = "clarifying"  # 澄清中
    UNKNOWN = "unknown"  # 未识别


class ResolutionMethod(str, Enum):
    """解决方式"""
    RAG = "rag"  # RAG知识检索
    FUNCTION_CALL = "function_call"  # 工具调用
    HUMAN = "human"  # 转人工


class Message(BaseModel):
    """对话消息"""
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SlotInfo(BaseModel):
    """槽位信息"""
    name: str  # 槽位名称
    description: str  # 槽位描述
    required: bool = True  # 是否必填
    value: Optional[str] = None  # 槽位值
    extracted: bool = False  # 是否已提取


class IntentTemplate(BaseModel):
    """意图识别模板"""
    intent_name: str  # 用户意图
    intent_description: str  # 意图描述
    slots: List[SlotInfo]  # 关键槽位
    resolution_method: ResolutionMethod  # 解决方式
    example_queries: List[str]  # 用户话术实例


class KnowledgeItem(BaseModel):
    """知识库条目"""
    category: str  # 知识类别
    topic: str  # 主题
    question: str  # 示例问题
    answer: str  # 答案


class ConversationState(BaseModel):
    """对话状态"""
    user_id: str
    session_id: str
    current_intent: Optional[str] = None
    intent_status: IntentStatus = IntentStatus.UNKNOWN
    slots: Dict[str, SlotInfo] = Field(default_factory=dict)
    clarification_count: int = 0  # 澄清次数
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)


class ChatRequest(BaseModel):
    """聊天请求"""
    user_id: str
    session_id: Optional[str] = None
    message: str


class ChatResponse(BaseModel):
    """聊天响应"""
    session_id: str
    message: str
    intent: Optional[str] = None
    intent_status: IntentStatus = IntentStatus.UNKNOWN
    need_clarification: bool = False
    transfer_to_human: bool = False


class SessionInfo(BaseModel):
    """会话信息"""
    session_id: str
    user_id: str
    created_at: datetime
    updated_at: datetime
    message_count: int
    last_message: Optional[str] = None
