"""
晨星家居智能客服助手 - Agent工具定义
定义可供Agent调用的业务工具
"""
from typing import Dict, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field

from app.core.logger import agent_logger


class OrderQueryInput(BaseModel):
    """订单查询输入"""
    order_id: str = Field(description="订单号")


class LogisticsQueryInput(BaseModel):
    """物流查询输入"""
    order_id: str = Field(description="订单号")


class ReturnRequestInput(BaseModel):
    """退货申请输入"""
    order_id: str = Field(description="订单号")
    reason: str = Field(description="退货原因")
    description: Optional[str] = Field(default=None, description="问题描述")


class AddressModifyInput(BaseModel):
    """地址修改输入"""
    order_id: str = Field(description="订单号")
    address_type: str = Field(description="地址类型: shipping(收货地址) 或 invoice(发票地址)")
    new_address: str = Field(description="新地址")


class InvoiceRequestInput(BaseModel):
    """发票申请输入"""
    order_id: str = Field(description="订单号")
    invoice_type: str = Field(description="发票类型: personal(个人) 或 company(企业)")
    invoice_title: str = Field(description="发票抬头")
    tax_number: Optional[str] = Field(default=None, description="税号(企业发票必填)")


@tool("query_order", args_schema=OrderQueryInput)
def query_order(order_id: str) -> Dict[str, Any]:
    """
    查询订单详情，包括订单状态、商品信息、金额等。
    当用户询问订单相关问题时使用此工具。
    """
    agent_logger.info(f"[工具调用] 查询订单: {order_id}")

    # 模拟订单数据（实际项目中应调用订单系统API）
    mock_orders = {
        "MS20231201001": {
            "order_id": "MS20231201001",
            "status": "已发货",
            "products": [
                {"name": "北欧简约实木餐桌", "quantity": 1, "price": 1299},
                {"name": "配套餐椅", "quantity": 4, "price": 299}
            ],
            "total_amount": 2495,
            "create_time": "2023-12-01 14:30:00",
            "shipping_address": "上海市浦东新区张江高科技园区XX路XX号"
        },
        "MS20231205002": {
            "order_id": "MS20231205002",
            "status": "待发货",
            "products": [
                {"name": "日式收纳柜", "quantity": 2, "price": 599}
            ],
            "total_amount": 1198,
            "create_time": "2023-12-05 10:15:00",
            "shipping_address": "北京市朝阳区建国路XX号"
        }
    }

    if order_id in mock_orders:
        return {"success": True, "data": mock_orders[order_id]}
    else:
        return {"success": False, "message": f"未找到订单号为 {order_id} 的订单"}


@tool("query_logistics", args_schema=LogisticsQueryInput)
def query_logistics(order_id: str) -> Dict[str, Any]:
    """
    查询订单物流信息，包括快递公司、运单号、物流轨迹等。
    当用户询问物流状态、快递进度时使用此工具。
    """
    agent_logger.info(f"[工具调用] 查询物流: {order_id}")

    # 模拟物流数据
    mock_logistics = {
        "MS20231201001": {
            "order_id": "MS20231201001",
            "carrier": "顺丰速运",
            "tracking_number": "SF1234567890",
            "status": "运输中",
            "estimated_delivery": "2023-12-08",
            "tracks": [
                {"time": "2023-12-06 18:30", "location": "上海转运中心", "status": "已到达"},
                {"time": "2023-12-05 20:00", "location": "杭州发货仓", "status": "已发出"},
                {"time": "2023-12-05 15:00", "location": "杭州发货仓", "status": "已揽收"}
            ]
        }
    }

    if order_id in mock_logistics:
        return {"success": True, "data": mock_logistics[order_id]}
    else:
        return {"success": False, "message": f"订单 {order_id} 暂无物流信息，可能尚未发货"}


@tool("submit_return_request", args_schema=ReturnRequestInput)
def submit_return_request(order_id: str, reason: str, description: Optional[str] = None) -> Dict[str, Any]:
    """
    提交退货/退款申请。
    当用户要求退货、退款时使用此工具。
    """
    agent_logger.info(f"[工具调用] 提交退货申请: 订单={order_id}, 原因={reason}")

    # 模拟退货申请处理
    return {
        "success": True,
        "data": {
            "return_id": f"RT{order_id[-6:]}001",
            "order_id": order_id,
            "status": "待审核",
            "reason": reason,
            "description": description,
            "message": "退货申请已提交，我们会在1-2个工作日内审核并与您联系。",
            "next_steps": [
                "等待客服审核",
                "审核通过后，我们会发送退货地址",
                "请将商品寄回并提供快递单号",
                "收到商品后3-5个工作日内完成退款"
            ]
        }
    }


@tool("modify_address", args_schema=AddressModifyInput)
def modify_address(order_id: str, address_type: str, new_address: str) -> Dict[str, Any]:
    """
    修改订单地址，包括收货地址和发票地址。
    当用户要求修改地址时使用此工具。
    """
    agent_logger.info(f"[工具调用] 修改地址: 订单={order_id}, 类型={address_type}")

    address_type_name = "收货地址" if address_type == "shipping" else "发票地址"

    # 检查订单状态（模拟）
    # 实际项目中需要调用订单系统检查订单是否可以修改地址
    return {
        "success": True,
        "data": {
            "order_id": order_id,
            "address_type": address_type_name,
            "new_address": new_address,
            "message": f"{address_type_name}已更新为: {new_address}"
        }
    }


@tool("request_invoice", args_schema=InvoiceRequestInput)
def request_invoice(
        order_id: str,
        invoice_type: str,
        invoice_title: str,
        tax_number: Optional[str] = None
) -> Dict[str, Any]:
    """
    申请发票或修改发票信息。
    当用户需要开发票或修改发票信息时使用此工具。
    """
    agent_logger.info(f"[工具调用] 申请发票: 订单={order_id}, 类型={invoice_type}")

    invoice_type_name = "个人发票" if invoice_type == "personal" else "企业发票"

    if invoice_type == "company" and not tax_number:
        return {
            "success": False,
            "message": "企业发票需要提供税号，请提供您的企业税号"
        }

    return {
        "success": True,
        "data": {
            "invoice_id": f"INV{order_id[-6:]}001",
            "order_id": order_id,
            "invoice_type": invoice_type_name,
            "invoice_title": invoice_title,
            "tax_number": tax_number,
            "status": "处理中",
            "message": f"{invoice_type_name}申请成功，预计1-3个工作日内开具并发送至您的邮箱"
        }
    }


@tool("transfer_to_human")
def transfer_to_human() -> Dict[str, Any]:
    """
    转接人工客服。
    当AI无法处理用户问题或用户主动要求人工服务时使用此工具。
    """
    agent_logger.info("[工具调用] 转接人工客服")

    return {
        "success": True,
        "data": {
            "status": "transferring",
            "message": "正在为您转接人工客服，请稍候...",
            "estimated_wait_time": "约2-5分钟",
            "queue_position": 3
        }
    }


# 导出所有工具
ALL_TOOLS = [
    query_order,
    query_logistics,
    submit_return_request,
    modify_address,
    request_invoice,
    transfer_to_human
]
