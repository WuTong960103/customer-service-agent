"""
晨星家居智能客服助手 - 日志配置模块
"""
import sys
from pathlib import Path
from loguru import logger
from app.core.config import settings


def setup_logger():
    """配置日志系统"""
    # 移除默认处理器
    logger.remove()

    # 日志目录
    log_dir = Path(settings.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    # 日志格式
    log_format = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
        "<level>{message}</level>"
    )

    # 控制台输出
    logger.add(
        sys.stdout,
        format=log_format,
        level=settings.log_level,
        colorize=True,
    )

    # Agent运行日志文件
    logger.add(
        log_dir / "agent_{time:YYYY-MM-DD}.log",
        format=log_format,
        level="DEBUG",
        rotation="00:00",  # 每天轮转
        retention="30 days",  # 保留30天
        compression="gz",
        filter=lambda record: "agent" in record["extra"].get("module", ""),
    )

    # 通用日志文件
    logger.add(
        log_dir / "app_{time:YYYY-MM-DD}.log",
        format=log_format,
        level=settings.log_level,
        rotation="00:00",
        retention="30 days",
        compression="gz",
    )

    # 错误日志文件
    logger.add(
        log_dir / "error_{time:YYYY-MM-DD}.log",
        format=log_format,
        level="ERROR",
        rotation="00:00",
        retention="30 days",
        compression="gz",
    )

    return logger


# 创建专用的Agent日志记录器
def get_agent_logger():
    """获取Agent专用日志记录器"""
    return logger.bind(module="agent")


# 初始化日志
setup_logger()
agent_logger = get_agent_logger()
