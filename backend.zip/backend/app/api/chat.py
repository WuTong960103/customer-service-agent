"""
晨星家居智能客服助手 - 聊天API接口
"""
from typing import Optional
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from sse_starlette.sse import EventSourceResponse
import json

from app.core.logger import logger
from app.models.schemas import ChatRequest, ChatResponse, SessionInfo
from app.services.conversation import conversation_manager
from app.services.agent import customer_service_agent

router = APIRouter(prefix="/chat", tags=["聊天"])


@router.post("/sessions")
async def create_session(user_id: str) -> dict:
    """
    创建新会话

    Args:
        user_id: 用户ID

    Returns:
        会话信息
    """
    try:
        session_id = conversation_manager.create_session(user_id)
        return {
            "success": True,
            "data": {
                "session_id": session_id,
                "user_id": user_id
            }
        }
    except Exception as e:
        logger.error(f"创建会话失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions")
async def get_user_sessions(user_id: str) -> dict:
    """
    获取用户的所有会话

    Args:
        user_id: 用户ID

    Returns:
        会话列表
    """
    try:
        sessions = conversation_manager.get_user_sessions(user_id)
        return {
            "success": True,
            "data": [
                {
                    "session_id": s.session_id,
                    "created_at": s.created_at.isoformat(),
                    "updated_at": s.updated_at.isoformat(),
                    "message_count": s.message_count,
                    "last_message": s.last_message
                }
                for s in sessions
            ]
        }
    except Exception as e:
        logger.error(f"获取会话列表失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/sessions/{session_id}")
async def delete_session(user_id: str, session_id: str) -> dict:
    """
    删除会话

    Args:
        user_id: 用户ID
        session_id: 会话ID

    Returns:
        操作结果
    """
    try:
        success = conversation_manager.delete_session(user_id, session_id)
        return {
            "success": success,
            "message": "会话已删除" if success else "删除失败"
        }
    except Exception as e:
        logger.error(f"删除会话失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/messages")
async def get_session_messages(user_id: str, session_id: str, limit: Optional[int] = None) -> dict:
    """
    获取会话消息历史

    Args:
        user_id: 用户ID
        session_id: 会话ID
        limit: 消息数量限制

    Returns:
        消息列表
    """
    try:
        messages = conversation_manager.get_messages(user_id, session_id, limit)
        return {
            "success": True,
            "data": [
                {
                    "role": "user" if msg.type == "human" else "assistant",
                    "content": msg.content
                }
                for msg in messages
            ]
        }
    except Exception as e:
        logger.error(f"获取消息历史失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/message")
async def send_message(request: ChatRequest):
    """
    发送消息（非流式）

    Args:
        request: 聊天请求

    Returns:
        聊天响应
    """
    try:
        # 如果没有session_id，创建新会话
        session_id = request.session_id
        if not session_id:
            session_id = conversation_manager.create_session(request.user_id)

        # 收集完整响应
        full_response = ""
        async for chunk in customer_service_agent.process_message(
                request.user_id,
                session_id,
                request.message
        ):
            full_response += chunk

        return {
            "success": True,
            "data": {
                "session_id": session_id,
                "message": full_response
            }
        }
    except Exception as e:
        logger.error(f"处理消息失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/message/stream")
async def send_message_stream(request: ChatRequest):
    """
    发送消息（SSE流式）

    Args:
        request: 聊天请求

    Returns:
        SSE流式响应
    """
    # 如果没有session_id，创建新会话
    session_id = request.session_id
    if not session_id:
        session_id = conversation_manager.create_session(request.user_id)

    async def event_generator():
        try:
            # 首先发送session_id
            yield {
                "event": "session",
                "data": json.dumps({"session_id": session_id})
            }

            # 流式发送消息
            async for chunk in customer_service_agent.process_message(
                    request.user_id,
                    session_id,
                    request.message
            ):
                yield {
                    "event": "message",
                    "data": json.dumps({"content": chunk})
                }

            # 发送完成信号
            yield {
                "event": "done",
                "data": json.dumps({"status": "completed"})
            }

        except Exception as e:
            logger.error(f"流式处理消息失败: {e}")
            yield {
                "event": "error",
                "data": json.dumps({"error": str(e)})
            }

    return EventSourceResponse(event_generator())
