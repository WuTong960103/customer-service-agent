"""
晨星家居智能客服助手 - 数据管理API接口
用于导入意图模板和知识库数据
"""
import json
from typing import List
from fastapi import APIRouter, HTTPException, UploadFile, File
import pandas as pd

from app.core.logger import logger
from app.models.schemas import IntentTemplate, KnowledgeItem, SlotInfo, ResolutionMethod
from app.services.embedding import vector_store_service

router = APIRouter(prefix="/data", tags=["数据管理"])


@router.post("/intents/import")
async def import_intents(file: UploadFile = File(...)) -> dict:
    """
    从Excel导入意图模板数据

    Excel格式要求:
    - intent_name: 用户意图
    - intent_description: 意图描述
    - slots: 关键槽位 (JSON格式: [{"name": "xxx", "description": "xxx", "required": true}])
    - resolution_method: 解决方式 (rag/function_call/human)
    - example_queries: 用户话术实例 (用|分隔多个示例)

    Args:
        file: Excel文件

    Returns:
        导入结果
    """
    try:
        # 读取Excel
        df = pd.read_excel(file.file)
        logger.info(f"读取到 {len(df)} 条意图数据")

        # 验证必要列
        required_columns = ["intent_name", "intent_description", "slots", "resolution_method", "example_queries"]
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise HTTPException(
                status_code=400,
                detail=f"缺少必要列: {missing_columns}"
            )

        # 处理数据
        documents = []
        metadatas = []
        ids = []

        for idx, row in df.iterrows():
            try:
                # 解析槽位
                slots_data = row["slots"]
                if isinstance(slots_data, str):
                    slots = json.loads(slots_data)
                else:
                    slots = []

                # 解析示例话术
                examples = row["example_queries"].split("|") if isinstance(row["example_queries"], str) else []

                # 构建意图数据
                intent_data = {
                    "intent_name": row["intent_name"],
                    "intent_description": row["intent_description"],
                    "slots": slots,
                    "resolution_method": row["resolution_method"],
                    "example_queries": examples
                }

                # 将意图数据和示例话术组合为文档内容
                doc_content = json.dumps(intent_data, ensure_ascii=False)

                documents.append(doc_content)
                metadatas.append({
                    "intent_name": row["intent_name"],
                    "type": "intent"
                })
                ids.append(f"intent_{idx}")

                # 同时为每个示例话术创建单独的文档，提高检索准确性
                for ex_idx, example in enumerate(examples):
                    if example.strip():
                        documents.append(example.strip())
                        metadatas.append({
                            "intent_name": row["intent_name"],
                            "type": "example",
                            "full_intent": doc_content
                        })
                        ids.append(f"intent_{idx}_example_{ex_idx}")

            except Exception as e:
                logger.warning(f"处理第 {idx + 1} 行数据失败: {e}")
                continue

        # 添加到向量库
        if documents:
            intent_store = vector_store_service.get_intent_store()
            intent_store.add_texts(
                texts=documents,
                metadatas=metadatas,
                ids=ids
            )
            logger.info(f"成功导入 {len(documents)} 条意图数据到向量库")

        return {
            "success": True,
            "message": f"成功导入 {len(df)} 条意图模板",
            "total_documents": len(documents)
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"导入意图数据失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/knowledge/import")
async def import_knowledge(file: UploadFile = File(...)) -> dict:
    """
    从Excel导入知识库数据

    Excel格式要求:
    - category: 知识类别
    - topic: 主题
    - question: 示例问题
    - answer: 答案

    Args:
        file: Excel文件

    Returns:
        导入结果
    """
    try:
        # 读取Excel
        df = pd.read_excel(file.file)
        logger.info(f"读取到 {len(df)} 条知识数据")

        # 验证必要列
        required_columns = ["category", "topic", "question", "answer"]
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise HTTPException(
                status_code=400,
                detail=f"缺少必要列: {missing_columns}"
            )

        # 处理数据
        documents = []
        metadatas = []
        ids = []

        for idx, row in df.iterrows():
            try:
                # 构建文档内容（问答对）
                doc_content = f"问题: {row['question']}\n答案: {row['answer']}"

                documents.append(doc_content)
                metadatas.append({
                    "category": row["category"],
                    "topic": row["topic"],
                    "question": row["question"],
                    "type": "knowledge"
                })
                ids.append(f"knowledge_{idx}")

            except Exception as e:
                logger.warning(f"处理第 {idx + 1} 行数据失败: {e}")
                continue

        # 添加到向量库
        if documents:
            knowledge_store = vector_store_service.get_knowledge_store()
            knowledge_store.add_texts(
                texts=documents,
                metadatas=metadatas,
                ids=ids
            )
            logger.info(f"成功导入 {len(documents)} 条知识数据到向量库")

        return {
            "success": True,
            "message": f"成功导入 {len(df)} 条知识",
            "total_documents": len(documents)
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"导入知识数据失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/intents/clear")
async def clear_intents() -> dict:
    """清空意图数据库"""
    try:
        intent_store = vector_store_service.get_intent_store()
        # 获取所有文档ID并删除
        collection = intent_store._collection
        all_ids = collection.get()["ids"]
        if all_ids:
            collection.delete(ids=all_ids)
        return {"success": True, "message": "意图数据库已清空"}
    except Exception as e:
        logger.error(f"清空意图数据库失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/knowledge/clear")
async def clear_knowledge() -> dict:
    """清空知识库"""
    try:
        knowledge_store = vector_store_service.get_knowledge_store()
        # 获取所有文档ID并删除
        collection = knowledge_store._collection
        all_ids = collection.get()["ids"]
        if all_ids:
            collection.delete(ids=all_ids)
        return {"success": True, "message": "知识库已清空"}
    except Exception as e:
        logger.error(f"清空知识库失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/intents/count")
async def get_intents_count() -> dict:
    """获取意图数据数量"""
    try:
        intent_store = vector_store_service.get_intent_store()
        count = intent_store._collection.count()
        return {"success": True, "count": count}
    except Exception as e:
        logger.error(f"获取意图数据数量失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/knowledge/count")
async def get_knowledge_count() -> dict:
    """获取知识库数量"""
    try:
        knowledge_store = vector_store_service.get_knowledge_store()
        count = knowledge_store._collection.count()
        return {"success": True, "count": count}
    except Exception as e:
        logger.error(f"获取知识库数量失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))
