"""
晨星家居智能客服助手 - 用户管理API
"""
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.user import user_service
from app.services.conversation import conversation_manager

router = APIRouter(prefix="/user", tags=["用户管理"])


class RegisterRequest(BaseModel):
    """注册请求"""
    username: str
    password: str
    nickname: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None


class LoginRequest(BaseModel):
    """登录请求"""
    username: str
    password: str


class UpdateUserRequest(BaseModel):
    """更新用户信息请求"""
    nickname: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    avatar: Optional[str] = None


class ChangePasswordRequest(BaseModel):
    """修改密码请求"""
    old_password: str
    new_password: str


@router.post("/register")
async def register(request: RegisterRequest):
    """
    用户注册

    - **username**: 用户名（必填）
    - **password**: 密码（必填）
    - **nickname**: 昵称（可选）
    - **email**: 邮箱（可选）
    - **phone**: 手机号（可选）
    """
    result = user_service.register(
        username=request.username,
        password=request.password,
        nickname=request.nickname,
        email=request.email,
        phone=request.phone
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/login")
async def login(request: LoginRequest):
    """
    用户登录

    - **username**: 用户名
    - **password**: 密码
    """
    result = user_service.login(
        username=request.username,
        password=request.password
    )
    if not result["success"]:
        raise HTTPException(status_code=401, detail=result["message"])
    return result


@router.get("/{user_id}")
async def get_user(user_id: str):
    """
    获取用户信息

    - **user_id**: 用户ID
    """
    user = user_service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return {"success": True, "data": user}


@router.put("/{user_id}")
async def update_user(user_id: str, request: UpdateUserRequest):
    """
    更新用户信息

    - **user_id**: 用户ID
    - **nickname**: 昵称（可选）
    - **email**: 邮箱（可选）
    - **phone**: 手机号（可选）
    - **avatar**: 头像URL（可选）
    """
    result = user_service.update_user(
        user_id=user_id,
        nickname=request.nickname,
        email=request.email,
        phone=request.phone,
        avatar=request.avatar
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/{user_id}/change-password")
async def change_password(user_id: str, request: ChangePasswordRequest):
    """
    修改密码

    - **user_id**: 用户ID
    - **old_password**: 原密码
    - **new_password**: 新密码
    """
    result = user_service.change_password(
        user_id=user_id,
        old_password=request.old_password,
        new_password=request.new_password
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.get("/{user_id}/sessions")
async def get_user_sessions(user_id: str):
    """
    获取用户的所有会话（对话历史绑定）

    - **user_id**: 用户ID
    """
    # 验证用户是否存在
    if not user_service.validate_user(user_id):
        raise HTTPException(status_code=404, detail="用户不存在")

    sessions = conversation_manager.get_user_sessions(user_id)
    return {
        "success": True,
        "data": [
            {
                "session_id": s.session_id,
                "created_at": s.created_at.isoformat(),
                "updated_at": s.updated_at.isoformat(),
                "message_count": s.message_count,
                "last_message": s.last_message
            }
            for s in sessions
        ]
    }


@router.get("/{user_id}/sessions/{session_id}/messages")
async def get_session_messages(user_id: str, session_id: str, limit: Optional[int] = None):
    """
    获取用户特定会话的消息历史

    - **user_id**: 用户ID
    - **session_id**: 会话ID
    - **limit**: 返回消息数量限制（可选）
    """
    # 验证用户是否存在
    if not user_service.validate_user(user_id):
        raise HTTPException(status_code=404, detail="用户不存在")

    messages = conversation_manager.get_messages(user_id, session_id, limit)
    return {
        "success": True,
        "data": [
            {
                "role": "user" if msg.type == "human" else "assistant",
                "content": msg.content,
                "metadata": msg.additional_kwargs
            }
            for msg in messages
        ]
    }
