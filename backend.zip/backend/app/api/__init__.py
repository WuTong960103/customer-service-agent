"""
晨星家居智能客服助手 - API路由模块
"""
from fastapi import APIRouter
from app.api.chat import router as chat_router
from app.api.data import router as data_router
from app.api.user import router as user_router

# 创建主路由
api_router = APIRouter(prefix="/api/v1")

# 注册子路由
api_router.include_router(chat_router)
api_router.include_router(data_router)
api_router.include_router(user_router)

__all__ = ["api_router"]
