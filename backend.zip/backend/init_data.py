"""
晨星家居智能客服助手 - 数据初始化脚本
用于首次启动后导入示例数据到向量数据库
"""
import asyncio
import sys
import time
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from app.core.logger import logger
from app.services.embedding import vector_store_service
from app.utils.generate_sample_data import create_intent_template_excel, create_knowledge_excel
import json


def add_texts_with_retry(store, texts, metadatas, ids, batch_size=5, max_retries=3):
    """分批添加文本，带重试机制"""
    total = len(texts)
    for i in range(0, total, batch_size):
        batch_texts = texts[i:i+batch_size]
        batch_metadatas = metadatas[i:i+batch_size]
        batch_ids = ids[i:i+batch_size]

        for attempt in range(max_retries):
            try:
                store.add_texts(
                    texts=batch_texts,
                    metadatas=batch_metadatas,
                    ids=batch_ids
                )
                logger.info(f"  已导入 {min(i+batch_size, total)}/{total} 条")
                time.sleep(0.5)  # 添加延迟避免请求过快
                break
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"  批次 {i//batch_size + 1} 失败，重试中... ({e})")
                    time.sleep(2)  # 重试前等待
                else:
                    raise e


def init_intent_data():
    """初始化意图数据"""
    logger.info("开始初始化意图数据...")

    # 获取意图数据
    df = create_intent_template_excel()

    documents = []
    metadatas = []
    ids = []

    for idx, row in df.iterrows():
        # 解析槽位
        slots_data = row["slots"]
        if isinstance(slots_data, str):
            slots = json.loads(slots_data)
        else:
            slots = []

        # 解析示例话术
        examples = row["example_queries"].split("|") if isinstance(row["example_queries"], str) else []

        # 构建意图数据
        intent_data = {
            "intent_name": row["intent_name"],
            "intent_description": row["intent_description"],
            "slots": slots,
            "resolution_method": row["resolution_method"],
            "example_queries": examples
        }

        doc_content = json.dumps(intent_data, ensure_ascii=False)

        documents.append(doc_content)
        metadatas.append({
            "intent_name": row["intent_name"],
            "type": "intent"
        })
        ids.append(f"intent_{idx}")

        # 为每个示例话术创建单独的文档
        for ex_idx, example in enumerate(examples):
            if example.strip():
                documents.append(example.strip())
                metadatas.append({
                    "intent_name": row["intent_name"],
                    "type": "example",
                    "full_intent": doc_content
                })
                ids.append(f"intent_{idx}_example_{ex_idx}")

    # 添加到向量库
    if documents:
        intent_store = vector_store_service.get_intent_store()
        add_texts_with_retry(intent_store, documents, metadatas, ids)
        logger.info(f"成功导入 {len(documents)} 条意图数据")

    return len(documents)


def init_knowledge_data():
    """初始化知识库数据"""
    logger.info("开始初始化知识库数据...")

    # 获取知识数据
    df = create_knowledge_excel()

    documents = []
    metadatas = []
    ids = []

    for idx, row in df.iterrows():
        doc_content = f"问题: {row['question']}\n答案: {row['answer']}"

        documents.append(doc_content)
        metadatas.append({
            "category": row["category"],
            "topic": row["topic"],
            "question": row["question"],
            "type": "knowledge"
        })
        ids.append(f"knowledge_{idx}")

    # 添加到向量库
    if documents:
        knowledge_store = vector_store_service.get_knowledge_store()
        add_texts_with_retry(knowledge_store, documents, metadatas, ids)
        logger.info(f"成功导入 {len(documents)} 条知识数据")

    return len(documents)


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("晨星家居智能客服助手 - 数据初始化")
    logger.info("=" * 60)

    try:
        # 检查是否已有数据
        intent_store = vector_store_service.get_intent_store()
        knowledge_store = vector_store_service.get_knowledge_store()

        intent_count = intent_store._collection.count()
        knowledge_count = knowledge_store._collection.count()

        if intent_count > 0 or knowledge_count > 0:
            logger.info(f"检测到已有数据: 意图={intent_count}, 知识={knowledge_count}")
            response = input("是否清空现有数据重新导入? (y/n): ")
            if response.lower() == 'y':
                logger.info("清空现有数据...")
                # 删除所有文档
                intent_ids = intent_store._collection.get()['ids']
                if intent_ids:
                    intent_store._collection.delete(ids=intent_ids)
                knowledge_ids = knowledge_store._collection.get()['ids']
                if knowledge_ids:
                    knowledge_store._collection.delete(ids=knowledge_ids)
            else:
                logger.info("保留现有数据，退出")
                return

        # 导入数据
        intent_count = init_intent_data()
        knowledge_count = init_knowledge_data()

        logger.info("=" * 60)
        logger.info("数据初始化完成!")
        logger.info(f"意图数据: {intent_count} 条")
        logger.info(f"知识数据: {knowledge_count} 条")
        logger.info("=" * 60)

    except Exception as e:
        logger.error(f"数据初始化失败: {e}")
        raise


if __name__ == "__main__":
    main()
