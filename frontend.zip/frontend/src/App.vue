<template>
  <!-- 登录/注册弹窗 -->
  <div v-if="!isLoggedIn" class="auth-overlay">
    <div class="auth-modal">
      <div class="auth-header">
        <span class="auth-logo">&#127968;</span>
        <h2>晨星家居智能客服</h2>
      </div>
      <div class="auth-tabs">
        <button :class="{ active: authMode === 'login' }" @click="authMode = 'login'">登录</button>
        <button :class="{ active: authMode === 'register' }" @click="authMode = 'register'">注册</button>
      </div>
      <form @submit.prevent="handleAuth" class="auth-form">
        <div class="form-group">
          <input v-model="authForm.username" type="text" placeholder="用户名" required />
        </div>
        <div class="form-group">
          <input v-model="authForm.password" type="password" placeholder="密码" required />
        </div>
        <div v-if="authMode === 'register'" class="form-group">
          <input v-model="authForm.nickname" type="text" placeholder="昵称（可选）" />
        </div>
        <div v-if="authError" class="auth-error">{{ authError }}</div>
        <button type="submit" class="btn-auth" :disabled="authLoading">
          {{ authLoading ? '处理中...' : (authMode === 'login' ? '登录' : '注册') }}
        </button>
      </form>
    </div>
  </div>

  <div class="app-container" v-else>
    <header class="app-header">
      <div class="logo">
        <span class="logo-icon">&#127968;</span>
        <span class="logo-text">晨星家居</span>
      </div>
      <div class="header-title">智能客服助手</div>
      <div class="header-actions">
        <span class="user-info">{{ userInfo.nickname || userInfo.username }}</span>
        <button class="btn-new-chat" @click="createNewSession">
          <span>+</span> 新对话
        </button>
        <button class="btn-logout" @click="handleLogout">退出</button>
      </div>
    </header>

    <div class="app-content">
      <!-- 展开侧边栏按钮（折叠时显示） -->
      <button v-if="sidebarCollapsed" class="btn-expand-sidebar" @click="sidebarCollapsed = false">
        &#8250;
      </button>

      <!-- 侧边栏 - 历史会话 -->
      <aside class="sidebar" :class="{ collapsed: sidebarCollapsed }">
        <div class="sidebar-header">
          <h3>历史对话</h3>
          <button class="btn-toggle" @click="sidebarCollapsed = !sidebarCollapsed">
            &#8249;
          </button>
        </div>
        <div class="session-list">
          <div
            v-for="session in sessions"
            :key="session.session_id"
            class="session-item"
            :class="{ active: currentSessionId === session.session_id }"
            @click="switchSession(session.session_id)"
          >
            <div class="session-info">
              <div class="session-preview">{{ session.last_message || '新对话' }}</div>
              <div class="session-time">{{ formatTime(session.updated_at) }}</div>
            </div>
            <button class="btn-delete" @click.stop="deleteSession(session.session_id)">
              &times;
            </button>
          </div>
          <div v-if="sessions.length === 0" class="no-sessions">
            暂无历史对话
          </div>
        </div>
      </aside>

      <!-- 主聊天区域 -->
      <main class="chat-main">
        <div class="chat-messages" ref="messagesContainer">
          <div v-if="messages.length === 0" class="welcome-message">
            <div class="welcome-icon">&#128075;</div>
            <h2>您好，欢迎来到晨星家居！</h2>
            <p>我是您的智能客服助手，可以帮您处理：</p>
            <div class="quick-actions">
              <button @click="sendQuickMessage('查询我的订单')">查询订单</button>
              <button @click="sendQuickMessage('查看物流进度')">物流查询</button>
              <button @click="sendQuickMessage('我想退货')">退货退款</button>
              <button @click="sendQuickMessage('开发票')">发票申请</button>
            </div>
          </div>

          <div
            v-for="(msg, index) in messages"
            :key="index"
            class="message"
            :class="msg.role"
          >
            <div class="message-avatar">
              {{ msg.role === 'user' ? '&#128100;' : '&#129302;' }}
            </div>
            <div class="message-content">
              <div class="message-text" v-html="formatMessage(msg.content)"></div>
            </div>
          </div>

          <!-- 加载中指示器 -->
          <div v-if="isLoading" class="message assistant">
            <div class="message-avatar">&#129302;</div>
            <div class="message-content">
              <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>

        <!-- 输入区域 -->
        <div class="chat-input-area">
          <div class="input-wrapper">
            <textarea
              v-model="inputMessage"
              @keydown.enter.exact="handleEnterKey"
              placeholder="请输入您的问题..."
              rows="1"
              ref="inputRef"
            ></textarea>
            <button
              class="btn-send"
              :disabled="!inputMessage.trim() || isLoading"
              @click="sendMessage"
            >
              发送
            </button>
          </div>
          <div class="input-hint">按 Enter 发送，Shift+Enter 换行</div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'

// 用户认证相关
const isLoggedIn = ref(false)
const authMode = ref('login')
const authLoading = ref(false)
const authError = ref('')
const authForm = ref({
  username: '',
  password: '',
  nickname: ''
})
const userInfo = ref({
  user_id: '',
  username: '',
  nickname: ''
})

// 响应式数据
const inputMessage = ref('')
const isLoading = ref(false)
const sidebarCollapsed = ref(false)
const messagesContainer = ref(null)

// 会话数据
const sessions = ref([])
const currentSessionId = ref(null)
const messages = ref([])

// 用户ID (从登录状态获取)
const userId = ref('')

// 检查本地存储的登录状态
onMounted(() => {
  const savedUser = localStorage.getItem('userInfo')
  if (savedUser) {
    try {
      const user = JSON.parse(savedUser)
      userInfo.value = user
      userId.value = user.user_id
      isLoggedIn.value = true
      initChat()
    } catch (e) {
      localStorage.removeItem('userInfo')
    }
  }
})

// 初始化聊天
async function initChat() {
  await loadSessions()
  if (sessions.value.length === 0) {
    await createNewSession()
  } else {
    await switchSession(sessions.value[0].session_id)
  }
}

// 处理登录/注册
async function handleAuth() {
  authError.value = ''
  authLoading.value = true

  try {
    const endpoint = authMode.value === 'login' ? '/api/v1/user/login' : '/api/v1/user/register'
    const body = {
      username: authForm.value.username,
      password: authForm.value.password
    }
    if (authMode.value === 'register' && authForm.value.nickname) {
      body.nickname = authForm.value.nickname
    }

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })

    const data = await response.json()

    if (!response.ok) {
      authError.value = data.detail || '操作失败'
      return
    }

    if (data.success) {
      userInfo.value = data.data
      userId.value = data.data.user_id
      isLoggedIn.value = true
      localStorage.setItem('userInfo', JSON.stringify(data.data))

      // 重置表单
      authForm.value = { username: '', password: '', nickname: '' }

      // 初始化聊天
      await initChat()
    } else {
      authError.value = data.message || '操作失败'
    }
  } catch (error) {
    console.error('认证失败:', error)
    authError.value = '网络错误，请稍后重试'
  } finally {
    authLoading.value = false
  }
}

// 退出登录
function handleLogout() {
  isLoggedIn.value = false
  userInfo.value = { user_id: '', username: '', nickname: '' }
  userId.value = ''
  sessions.value = []
  messages.value = []
  currentSessionId.value = null
  localStorage.removeItem('userInfo')
}

// 加载会话列表
async function loadSessions() {
  try {
    const response = await fetch(`/api/v1/chat/sessions?user_id=${userId.value}`)
    const data = await response.json()
    if (data.success) {
      sessions.value = data.data
    }
  } catch (error) {
    console.error('加载会话列表失败:', error)
  }
}

// 创建新会话
async function createNewSession() {
  try {
    const response = await fetch(`/api/v1/chat/sessions?user_id=${userId.value}`, {
      method: 'POST'
    })
    const data = await response.json()
    if (data.success) {
      currentSessionId.value = data.data.session_id
      messages.value = []
      await loadSessions()
    }
  } catch (error) {
    console.error('创建会话失败:', error)
  }
}

// 切换会话
async function switchSession(sessionId) {
  currentSessionId.value = sessionId
  await loadMessages(sessionId)
}

// 加载会话消息
async function loadMessages(sessionId) {
  try {
    const response = await fetch(
      `/api/v1/chat/sessions/${sessionId}/messages?user_id=${userId.value}`
    )
    const data = await response.json()
    if (data.success) {
      messages.value = data.data
      scrollToBottom()
    }
  } catch (error) {
    console.error('加载消息失败:', error)
  }
}

// 删除会话
async function deleteSession(sessionId) {
  if (!confirm('确定要删除这个对话吗？')) return

  try {
    const response = await fetch(
      `/api/v1/chat/sessions/${sessionId}?user_id=${userId.value}`,
      { method: 'DELETE' }
    )
    const data = await response.json()
    if (data.success) {
      await loadSessions()
      if (currentSessionId.value === sessionId) {
        if (sessions.value.length > 0) {
          await switchSession(sessions.value[0].session_id)
        } else {
          await createNewSession()
        }
      }
    }
  } catch (error) {
    console.error('删除会话失败:', error)
  }
}

// 发送消息
async function sendMessage() {
  const message = inputMessage.value.trim()
  if (!message || isLoading.value) return

  // 添加用户消息到界面
  messages.value.push({ role: 'user', content: message })
  inputMessage.value = ''
  isLoading.value = true
  scrollToBottom()

  try {
    // 使用SSE流式接收响应
    const response = await fetch('/api/v1/chat/message/stream', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        user_id: userId.value,
        session_id: currentSessionId.value,
        message: message
      })
    })

    const reader = response.body.getReader()
    const decoder = new TextDecoder()
    let assistantMessage = ''
    let messageAdded = false

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      const chunk = decoder.decode(value, { stream: true })
      const lines = chunk.split('\n')

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6))

            if (data.session_id) {
              // 更新session_id
              currentSessionId.value = data.session_id
            }

            if (data.content) {
              assistantMessage += data.content

              if (!messageAdded) {
                messages.value.push({ role: 'assistant', content: assistantMessage })
                messageAdded = true
              } else {
                messages.value[messages.value.length - 1].content = assistantMessage
              }
              scrollToBottom()
            }
          } catch (e) {
            // 忽略解析错误
          }
        }
      }
    }

    // 刷新会话列表
    await loadSessions()

  } catch (error) {
    console.error('发送消息失败:', error)
    messages.value.push({
      role: 'assistant',
      content: '抱歉，发送消息时遇到了问题，请稍后再试。'
    })
  } finally {
    isLoading.value = false
  }
}

// 快捷消息
function sendQuickMessage(message) {
  inputMessage.value = message
  sendMessage()
}

// 处理Enter键
function handleEnterKey(event) {
  if (!event.shiftKey) {
    event.preventDefault()
    sendMessage()
  }
}

// 滚动到底部
function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// 格式化消息 (支持简单的markdown)
function formatMessage(text) {
  if (!text) return ''
  return text
    .replace(/\n/g, '<br>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
}

// 格式化时间
function formatTime(timeStr) {
  if (!timeStr) return ''
  const date = new Date(timeStr)
  const now = new Date()
  const diff = now - date

  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'

  return date.toLocaleDateString('zh-CN', {
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}
</script>

<style scoped lang="scss">
// 样式在main.scss中定义
</style>
