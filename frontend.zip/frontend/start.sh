#!/bin/bash
# 晨星家居智能客服助手 - 前端启动脚本

# 进入前端目录
cd "$(dirname "$0")"

# 检查node_modules
if [ ! -d "node_modules" ]; then
    echo "安装前端依赖..."
    npm install
fi

# 启动开发服务器
echo "启动晨星家居智能客服助手前端..."
echo "访问地址: http://localhost:3000"
npm run dev
